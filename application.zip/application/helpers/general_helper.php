<?php

defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('fechaHumana')) {

    function fechaHumana($fecha = NULL, $full = FALSE) {
        $fecha = strtotime($fecha);

        $num = date('d', $fecha);
        $dia_adelante = date('w', $fecha);
        $mes = date('n', $fecha);
        $anio = date('Y', $fecha);

        $dia_adelantes = array('Domingo', 'Lunes', 'Martes', 'Mi&eacute;rcoles', 'Jueves', 'Viernes', 'S&aacute;bado');

        if ($full) {
            $meses = array('', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre');
        } else {
            $meses = array('', 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Agos', 'Set', 'Oct', 'Nov', 'Dic');
        }

        if ($full) {
            return $dia_adelantes[$dia_adelante] . ', ' . $num . ' de ' . $meses[$mes] . ' de ' . $anio;
        }

        return $num . ' de ' . $meses[$mes] . ' ' . $anio;
    }

}

if (!function_exists('mesletra')) {

    function mesletra($fecha = NULL){
        $fecha = strtotime($fecha);

        $mes = date('n', $fecha);
        $meses = array('', 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Agos', 'Set', 'Oct', 'Nov', 'Dic');
        
        return $meses[$mes];
    }
}

if (!function_exists('fechaLatina')) {

    function fechaLatina($fecha = NULL, $full = FALSE) {
        $fecha = strtotime($fecha);

        return date('d/m/Y' . (($full) ? ' H:i:s' : ''), $fecha);
    }

}

if (!function_exists('minifyHtml')) {

    function minifyHtml($output = NULL) {
        $output = preg_replace('/(?:(?:\/\*(?:[^*]|(?:\*+[^*\/]))*\*+\/)|(?:(?<!\:|\\\|\'|\")\/\/.*)|(?:<!\-\-(?:[^\[])*?\-\->))/', '', $output);
        $output = str_replace(array(PHP_EOL, "\t"), ' ', $output);
        $output = preg_replace('|\s\s+|', ' ', $output);

        return $output;
    }

}

if (!function_exists('inputback')) {

    function inputback($post) {
        $pag=$post['pagina'];
        $prohibidas = implode('|', array(
            'dataTable-',
            'empresa',
        ));

        $expresion = '/^(' . $prohibidas . ')+/';
        $output = array();

        foreach ($post as $key => $value) {
            if (!preg_match($expresion, $key)) {
                $output[] = array(
                    'nombre' => $key,
                    'valor' => $value,
                    'idpagina'=>$pag
                );
            }
        }

        return $output;
    }

}

if (!function_exists('inputbackGeneral')) {

    function inputbackGeneral($post) {
        $prohibidas = implode('|', array(
            'dataTable-',
            'empresa',
        ));

        $expresion = '/^(' . $prohibidas . ')+/';
        $output = array();

        foreach ($post as $key => $value) {
            if (!preg_match($expresion, $key)) {
                $output[] = array(
                    'nombre' => $key,
                    'valor' => $value
                );
            }
        }

        return $output;
    }

}

if (!function_exists('clearString')) {


    function clearString($str, $replace_with = "-") {
        $a = array('%','À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ', ' ');
        $b = array('jm','A', 'A', 'A','A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o', $replace_with);
        $str = str_replace($a, $b, $str);
        $str = preg_replace('/[^\.%A-Za-z0-9_-]/', '', $str);

        return (string) strtolower(trim($str));
    }

}

if (!function_exists('getFilex')) {

    function getFilex($path = NULL) {
        return $path . '?' . filemtime($path);
    }

}

if (!function_exists('getFilex')) {

    function getFilex($path = NULL) {
        return $path . '?' . filemtime($path);
    }

}