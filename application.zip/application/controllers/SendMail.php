<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class SendMail extends CI_Controller {
    public function __construct() {
        parent::__construct();
        // $this->load->library('My_PHPMailer');
        $this->load->model('frontend/contenido');
        $this->load->model('frontend/taxonomia');
        $this->load->model('frontend/mcontactos');
    }

    public function index() {}
    
    public function solicitar_vacante(){
        $post = $this->input->post(NULL, TRUE);

        if (!empty($post)) {
            $salon = $this->taxonomia->getSalon($post['grado'],$post['seccion']);
            if(!empty($salon)){
                date_default_timezone_set('America/Lima');
                $fecha = (new DateTime())->format('Y-m-d H:i:s');
                $post['matriculas']['codigo'] = null;
                $post['matriculas']['idalumno'] = null;
                $post['matriculas']['idsalon'] = $salon['idsalon'];
                $post['matriculas']['fecha'] = $fecha;
                $post['matriculas']['estado'] = 1;
                return $this->mcontactos->saveMatricula($post);
            }else{
               return $this->pageError(); 
            }
        }else{
            return $this->pageError();
        }
    }
    public function matricular(){
        $post = $this->input->post(NULL, TRUE);

        if (!empty($post)) {
            $this->mcontactos->saveAlumno($post);
            $post['matriculas']['idalumno'] = 1;
            $post['matriculas']['estado'] = 0;
            return $this->mcontactos->updateMatricula($post);
        }else{
            return $this->pageError();
        }
    }

    private function sendMail($data = array()) {
        $mailer = new PHPMailer();
        if (!empty($data)) {
            try {
                $mailer->CharSet = 'UTF-8';
                $mailer->isHTML(true);
                $mailer->setFrom($data['remitente']['email'], $data['remitente']['nombre']);
                foreach ($data['destinatarios'] as $key => $destinatario) {
                    $mailer->addAddress($destinatario['email'], $destinatario['nombre']);
                }
                $mailer->Subject = $data['asunto'];
                $mailer->msgHTML($data['mensaje']);
                return $mailer->send();
            } catch (Exception $e) {
                echo 'Message could not be sent.';
                echo 'Mailer Error: ' . $mailer->ErrorInfo;
            }
        }
    }
    public function pageError() {
     	$data = array(
            'empresa' => $this->contenido->getEmpresa()
        );
        $this->load->view('frontend/404',$data);
    }
    private function __output($html = NULL) {
        if (ENVIRONMENT === 'production') {
            $html = minifyHtml($html);
        }
        $this->output->set_output($html);
    }
}