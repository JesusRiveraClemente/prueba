<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Request extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('frontend/taxonomia');
        $this->load->model('frontend/contenido');
        $this->load->helper('general'); 
	}

	public function index(){
        $pagina = $this->taxonomia->getPaginaurl($this->uri->uri_string);
        
        $data = array(
            'empresa' => $this->contenido->getEmpresa(),
            'planes' => $this->contenido->getPlanes(),
            'beneficios' => $this->contenido->getBeneficios(),
            'eventos' => $this->contenido->getEventos()
        );
        
		if(isset($pagina)){
            $data = array(
                'pagina' => $pagina,
                'contenido' => $this->contenido->getContenido($pagina['idpagina'])
            )+$data;
		    $page = $pagina['template'];
            $output = $this->load->view('frontend/'.$page.'', $data, TRUE);
		}elseif ($this->uri->uri_string == "solicitar-vacante") {
            $data = array(
                'secciones' => $this->contenido->getSecciones(),
                'grados' => $this->contenido->getGrados()
            )+$data;
            $output = $this->load->view('frontend/solicitar-vacante', $data, TRUE);
        }else{
		    return $this->pageError();
		}

        // print_r($this->uri->uri_string);

        $this->output->set_header('Access-Control-Allow-Origin: *');
        return $this->__output($output);
	}
	
    public function matricular($codigo){
        $matricula = $this->taxonomia->getMatricula($codigo);
        $data = array(
            'empresa' => $this->contenido->getEmpresa(),
            'planes' => $this->contenido->getPlanes()
        );
        if(empty($matricula) && !isset($matricula)){
            return $this->pageError();
        }
        $output = $this->load->view('frontend/matricular', $data, TRUE);
        $this->output->set_header('Access-Control-Allow-Origin: *');
        return $this->__output($output);
    }

    public function plan_detalle($urlPlan){
        $pagina = $this->taxonomia->getPlanurl($urlPlan);
        $data = array(
            'pagina' => $pagina,
            'empresa' => $this->contenido->getEmpresa(),
            'planes' => $this->contenido->getPlanes()
        );
        if(empty($pagina) && !isset($pagina)){
            return $this->pageError();
        }
        $output = $this->load->view('frontend/plan-detalle', $data, TRUE);
        $this->output->set_header('Access-Control-Allow-Origin: *');
        return $this->__output($output);
    }

	public function pageError() {
     	$data = array(
            'empresa' => $this->contenido->getEmpresa()
        );
        $this->load->view('frontend/404',$data);
    }
	private function __output($html = NULL) {
        if (ENVIRONMENT === 'production') {
            $html = minifyHtml($html);
        }
        $this->output->set_output($html);
    }
}
