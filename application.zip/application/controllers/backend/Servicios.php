<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Servicios extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('backend/sistema');
        $this->load->model('backend/mservicios');
        $this->load->model('backend/musuarios');
        $this->load->model('backend/mcontenido');
        $this->load->helper('general');
        if ($this->session->has_userdata('manager')) {
            $this->manager = $this->session->userdata('manager');
        } else {
            redirect('manager');
        }
    }

    public function index() {
        $user=$this->manager['user']['idperfil'];
        $idmodulo=3;
        $data = array();
        $data['permiso']=$this->sistema->getPermisos($user,$idmodulo);
        $data['modulos']=$this->sistema->getModulos($user);
        $data['empresa']=$this->mcontenido->getEmpresa() ;
        $output = $this->load->view('backend/servicios', $data, TRUE);
        return $this->__output($output);
    }
    
    public function read() {
        $draw = $this->input->post('draw', TRUE);
        $search = $this->input->post('search', TRUE);
        $start = (int) $this->input->post('start', TRUE);
        $length = (int) $this->input->post('length', TRUE);
        $user = $this->manager['user']['idperfil'];
        $idmodulo = 4;
        $permiso = $this->sistema->getPermisos($user,$idmodulo);
        $servicios = $this->mservicios->getServicios($search['value'], $length, $start);
        $data = array();
        foreach ($servicios as $servicio) {
            $servicio['botones'] = '<center>';
            if($permiso['editar']==1){
                $servicio['botones'] .= '<a href="javascript: Exeperu.editServicio(' . $servicio['idservicio'] . ');" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-pencil"></i></a>';
            }
            if($permiso['eliminar']==1){
                $servicio['botones'] .= '&nbsp;&nbsp; | &nbsp;&nbsp;<a href="javascript: Exeperu.delServicio(' . $servicio['idservicio'] . ');" class="btn btn-danger btn-sm btn-flat"><i class="fa fa-trash-o"></i></a>';
            }
            $servicio['botones'] .= '</center>';
            $data[] = $servicio;
        }
        $dataObj = array(
            'draw' => $draw,
            'recordsTotal' => $this->mservicios->getTotal(),
            'recordsFiltered' => $this->mservicios->getTotal($search['value']),
            'data' => $data
        );
        $this->output->set_content_type('application/json');
        return $this->__output(json_encode($dataObj));
    }

    public function edit() {
        $idservicio = $this->input->post('id', TRUE);
        $data = array(
            'servicio' => $this->mservicios->getServicio($idservicio)         
        );
        $output = $this->load->view('backend/popups/edit_servicio', $data, TRUE);
        return $this->__output($output);
    }
    
    public function save(){
        $post = $this->input->post();
        $jm = array();
        if(empty($post['servicios']['descripcion'])){
            $errores[]="descripcion";
        }else{
            $jm[]="descripcion";
        }
        $post['sitemap']['url'] = clearString($post['sitemap']['url']);
        if(isset($errores) && !empty($errores)){
            $mensaje=array("mensaje"=>"Faltan registrar datos importantes","tipo"=>2,"errores"=>json_encode($errores),"jm"=>json_encode($jm));
        }else{
            if((int)$post['servicios']['idservicio']>0){
                $idservicio = $post['servicios']['idservicio'];
                $this->mservicios->updatesitemap($post);
                $this->mservicios->updateservicio($post);
                $mensaje = array("mensaje"=>"Servicio editado correctamente","tipo"=>1);
            }else{
                $idsitemap = $this->mservicios->savesitemap($post);
                $post['servicios']['idsitemap'] = $idsitemap;
                $idservicio = $this->mservicios->saveservicio($post);
                $mensaje=array("mensaje"=>"Servicio registrado correctamente","tipo"=>1);
            }
        }
        echo json_encode($mensaje);
    }

    public function delete(){
        $idservicio = $this->input->post('id');
        $servicio = $this->mservicios->getServicio($idservicio);
        $this->mservicios->deleteservicio($idservicio);
        $this->mservicios->deletesitemap($servicio['idsitemap']);
    }

    private function __output($html = NULL) {
        if (ENVIRONMENT === 'production') {
            $html = minifyHtml($html);
        }
        $this->output->set_output($html);
    }
}