<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class General extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('backend/sistema');
        $this->load->model('backend/mcontenido');
        $this->load->helper('general');
        if ($this->session->has_userdata('manager')) {
            $this->manager = $this->session->userdata('manager');
        } else {
            redirect('manager');
        }
    }
    
    public function index(){
        $user=$this->manager['user']['idperfil'];
        $idmodulo=2;
        $dataempresa = $this->mcontenido->getEmpresa();
        $data = array(
            'permiso' => $this->sistema->getPermisos($user,$idmodulo),
            'modulos' => $this->sistema->getModulos($user),
            'empresa' => $this->mcontenido->getEmpresa(),
            'tabs' => array(),
            'categorias'=>$this->sistema->getContenedoresG(),
            'modulos'=>$this->sistema->getModulos(),
            'variables' => $this->mcontenido->getVariablesG(),
            'dataempresa'=>$dataempresa
        );
        $output = $this->load->view('backend/general', $data, TRUE);
        return $this->__output($output);
    }
    
    public function guardar() {
        $post = $this->input->post(NULL, FALSE);
        $post = inputbackGeneral($post);

        if ($this->setVariableG($post)) {
            $mensaje=array("mensaje"=>"Datos registrados correctamente","tipo"=>1);
        }
        echo json_encode($mensaje);
    }
    
    public function delete(){
        $idp=$this->input->post('id');
        $this->mcontenido->deletepagina($idp);
    }

    public function setVariableG($variables = array(), $index = 0) {
        if ($this->mcontenido->setVariableG($variables[$index])) {
            $index++;
            if (isset($variables[$index]) && !empty($variables[$index])) {
                return $this->setVariableG($variables, $index);
            }
        }
        return TRUE;
    }

    private function __output($html = NULL) {
        if (ENVIRONMENT === 'production') {
            $html = minifyHtml($html);
        }
        $this->output->set_output($html);
    }
}