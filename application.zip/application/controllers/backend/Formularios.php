<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Formularios extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('backend/sistema');
        $this->load->model('backend/mcontenido');
        $this->load->model('backend/mformularios');
        $this->load->model('backend/musuarios');
        $this->load->helper('general');
        if ($this->session->has_userdata('manager')) {
            $this->manager = $this->session->userdata('manager');
        } else {
            redirect('manager');
        }
    }

    public function index() {
        $user=$this->manager['user']['idperfil'];
        $idmodulo=7;
        
        $data = array();
        $data['permiso']=$this->sistema->getPermisos($user,$idmodulo);
        $data['modulos']=$this->sistema->getModulos($user);
    
        $data['empresa']=$this->mcontenido->getEmpresa();        

        $output = $this->load->view('backend/formularios', $data, TRUE);

        return $this->__output($output);
    }
    
    public function read() {
        $draw = $this->input->post('draw', TRUE);
        $search = $this->input->post('search', TRUE);
        $start = (int) $this->input->post('start', TRUE);
        $length = (int) $this->input->post('length', TRUE);
        
        $user=$this->manager['user']['idperfil'];
        $idmodulo = 7;
        
        $permiso=$this->sistema->getPermisos($user,$idmodulo);
        $formularios = $this->mformularios->getFormularios($search['value'], $length, $start);
        $data = array();

        foreach ($formularios as $formulario) {
            $formulario['fechajm']=(new DateTime($formulario['fecha']))->format('d/m/Y H:i:s');

            $formulario['botones'] = '<center>';
            if($permiso['editar']==1){
                $formulario['botones'] .= '<a href="javascript: Exeperu.editFormulario(' . $formulario['idformulario'] . ');" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-pencil"></i></a>';
            }
            if($permiso['eliminar']==1){
                $formulario['botones'] .= '&nbsp;&nbsp; | &nbsp;&nbsp;<a href="javascript: Exeperu.delFormulario(' . $formulario['idformulario'] . ');" class="btn btn-danger btn-sm btn-flat"><i class="fa fa-trash-o"></i></a>';
            }
            $formulario['botones'] .= '</center>';

            $data[] = $formulario;
        }

        $dataObj = array(
            'draw' => $draw,
            'recordsTotal' => $this->mformularios->getTotal(),
            'recordsFiltered' => $this->mformularios->getTotal($search['value']),
            'data' => $data
        );

        $this->output->set_content_type('application/json');

        return $this->__output(json_encode($dataObj));
    }  
    
    public function edit() {
        $idformulario = $this->input->post('id', TRUE);

        $data = array(
            'formulario' => $this->mformularios->getFormulario($idformulario)              
        );

        $output = $this->load->view('backend/popups/edit_formulario', $data, TRUE);

        return $this->__output($output);
    }
    
    private function __output($html = NULL) {
        if (ENVIRONMENT === 'production') {
            $html = minifyHtml($html);
        }

        $this->output->set_output($html);
    }
}