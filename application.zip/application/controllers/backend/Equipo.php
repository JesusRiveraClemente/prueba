<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Equipo extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('backend/sistema');
        $this->load->model('backend/mprofesores');
        $this->load->model('backend/musuarios');
        $this->load->model('backend/mcontenido');
        $this->load->helper('general');
        if ($this->session->has_userdata('manager')) {
            $this->manager = $this->session->userdata('manager');
        } else {
            redirect('manager');
        }
    }

    public function index() {
        $user=$this->manager['user']['idperfil'];
        $idmodulo=4;
        $data = array();
        $data['permiso']=$this->sistema->getPermisos($user,$idmodulo);
        $data['modulos']=$this->sistema->getModulos($user);
        $data['empresa']=$this->mcontenido->getEmpresa() ;
        $output = $this->load->view('backend/nuestro-equipo', $data, TRUE);
        return $this->__output($output);
    }
    
    public function read() {
        $draw = $this->input->post('draw', TRUE);
        $search = $this->input->post('search', TRUE);
        $start = (int) $this->input->post('start', TRUE);
        $length = (int) $this->input->post('length', TRUE);
        $user = $this->manager['user']['idperfil'];
        $idmodulo = 4;
        $permiso = $this->sistema->getPermisos($user,$idmodulo);
        $profesores = $this->mprofesores->getProfesores($search['value'], $length, $start);
        $data = array();
        foreach ($profesores as $profesor) {
            $profesor['botones'] = '<center>';
            if($permiso['editar']==1){
                $profesor['botones'] .= '<a href="javascript: Exeperu.editProfesor(' . $profesor['idprofesor'] . ');" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-pencil"></i></a>';
            }
            if($permiso['eliminar']==1){
                $profesor['botones'] .= '&nbsp;&nbsp; | &nbsp;&nbsp;<a href="javascript: Exeperu.delProfesor(' . $profesor['idprofesor'] . ');" class="btn btn-danger btn-sm btn-flat"><i class="fa fa-trash-o"></i></a>';
            }
            $profesor['botones'] .= '</center>';
            $data[] = $profesor;
        }
        $dataObj = array(
            'draw' => $draw,
            'recordsTotal' => $this->mprofesores->getTotal(),
            'recordsFiltered' => $this->mprofesores->getTotal($search['value']),
            'data' => $data
        );
        $this->output->set_content_type('application/json');
        return $this->__output(json_encode($dataObj));
    }

    public function edit() {
        $idprofesor = $this->input->post('id', TRUE);
        $data = array(
            'profesor' => $this->mprofesores->getProfesor($idprofesor)         
        );
        $output = $this->load->view('backend/popups/edit_profesor', $data, TRUE);
        return $this->__output($output);
    }
    
    public function save(){
        $post = $this->input->post();
        $jm = array();

        if(isset($errores) && !empty($errores)){
            $mensaje=array("mensaje"=>"Faltan registrar datos importantes","tipo"=>2,"errores"=>json_encode($errores),"jm"=>json_encode($jm));
        }else{
            if((int)$post['profesores']['idprofesor']>0){
                $idprofesor = $post['profesores']['idprofesor'];
                $this->mprofesores->updateprofesor($post);
                $mensaje = array("mensaje"=>"Profesor editado correctamente","tipo"=>1);
            }else{
                $idprofesor = $this->mprofesores->saveprofesor($post);
                $mensaje=array("mensaje"=>"Profesor registrado correctamente","tipo"=>1);
            }
        }
        echo json_encode($mensaje);
    }

    public function delete(){
        $idprofesor = $this->input->post('id');
        $this->mprofesores->deleteprofesor($idprofesor);
    }

    private function __output($html = NULL) {
        if (ENVIRONMENT === 'production') {
            $html = minifyHtml($html);
        }
        $this->output->set_output($html);
    }
}