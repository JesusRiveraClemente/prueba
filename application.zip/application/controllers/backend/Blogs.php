<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Blogs extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('backend/sistema');
        $this->load->model('backend/mblogs');
        $this->load->model('backend/musuarios');
        $this->load->model('backend/mcontenido');
        $this->load->helper('general');
        if ($this->session->has_userdata('manager')) {
            $this->manager = $this->session->userdata('manager');
        } else {
            redirect('manager');
        }
    }

    public function index() {
        $user=$this->manager['user']['idperfil'];
        $idmodulo=5;
        $data = array();
        $data['permiso']=$this->sistema->getPermisos($user,$idmodulo);
        $data['modulos']=$this->sistema->getModulos($user);
        $data['empresa']=$this->mcontenido->getEmpresa() ;
        $output = $this->load->view('backend/blogs', $data, TRUE);
        return $this->__output($output);
    }
    
    public function read() {
        $draw = $this->input->post('draw', TRUE);
        $search = $this->input->post('search', TRUE);
        $start = (int) $this->input->post('start', TRUE);
        $length = (int) $this->input->post('length', TRUE);
        $user = $this->manager['user']['idperfil'];
        $idmodulo = 5;
        $permiso = $this->sistema->getPermisos($user,$idmodulo);
        $blogs = $this->mblogs->getBlogs($search['value'], $length, $start);
        $data = array();
        foreach ($blogs as $blog) {
            $blog['botones'] = '<center>';
            if($permiso['editar']==1){
                $blog['botones'] .= '<a href="javascript: Exeperu.editBlog(' . $blog['idblog'] . ');" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-pencil"></i></a>';
            }
            if($permiso['eliminar']==1){
                $blog['botones'] .= '&nbsp;&nbsp; | &nbsp;&nbsp;<a href="javascript: Exeperu.delBlog(' . $blog['idblog'] . ');" class="btn btn-danger btn-sm btn-flat"><i class="fa fa-trash-o"></i></a>';
            }
            $blog['botones'] .= '</center>';
            $data[] = $blog;
        }
        $dataObj = array(
            'draw' => $draw,
            'recordsTotal' => $this->mblogs->getTotal(),
            'recordsFiltered' => $this->mblogs->getTotal($search['value']),
            'data' => $data
        );
        $this->output->set_content_type('application/json');
        return $this->__output(json_encode($dataObj));
    }
    
    public function edit() {
        $idblog = $this->input->post('id', TRUE);
        $data = array(
            'blog' => $this->mblogs->getBlog($idblog),
            'comentarios' => $this->mblogs->getComentarios($idblog)
        );
        $output = $this->load->view('backend/popups/edit_blog', $data, TRUE);
        return $this->__output($output);
    }
    
    public function save(){
        $post = $this->input->post();
        $jm = array();
        if(empty($post['blogs']['titulo'])){
            $errores[]="titulo";
        }else{
            $jm[]="titulo";
        }
        $post['sitemap']['url'] = clearString($post['sitemap']['url']);
        if(isset($errores) && !empty($errores)){
            $mensaje=array("mensaje"=>"Faltan registrar datos importantes","tipo"=>2,"errores"=>json_encode($errores),"jm"=>json_encode($jm));
        }else{
            if((int)$post['blogs']['idblog']>0){
                $idblog = $post['blogs']['idblog'];
                $this->mblogs->updatesitemap($post);
                $this->mblogs->updateblog($post);
                $comentarios = json_decode($post['comentarios'],true);
                foreach ($comentarios as $comentario) {
                    $this->mblogs->updatecomentarios($comentario);
                }
                $mensaje = array("mensaje"=>"Blog editado correctamente","tipo"=>1);
            }else{
                $idsitemap = $this->mblogs->savesitemap($post);
                $post['blogs']['idsitemap'] = $idsitemap;
                $idblog = $this->mblogs->saveblog($post);
                $mensaje=array("mensaje"=>"Servicio registrado correctamente","tipo"=>1);
            }
        }
        echo json_encode($mensaje);
    }

    public function delete(){
        $idblog = $this->input->post('id');
        $blog = $this->mblogs->getBlog($idblog);
        $this->mblogs->deleteblog($idblog);
        $this->mblogs->deletesitemap($blog['idsitemap']);
    }

    private function __output($html = NULL) {
        if (ENVIRONMENT === 'production') {
            $html = minifyHtml($html);
        }
        $this->output->set_output($html);
    }
}