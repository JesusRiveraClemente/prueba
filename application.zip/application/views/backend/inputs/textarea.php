<div class="form-group">
    <label for="<?= $variable['nombre'] ?>">
        <?= $variable['label']; ?>
    </label>
    <textarea class="cke_1 cke cke_reset cke_chrome cke_editor_editor1 cke_ltr cke_browser_webkit form-control" name="<?= $variable['nombre'] ?>" id="<?= $variable['nombre'] ?>" rows="3"><?= isset($variable['valor']) ? $variable['valor'] : ''; ?></textarea>
</div>