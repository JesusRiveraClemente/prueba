<!DOCTYPE html>
<html>
    <head>
        <?= $this->load->view('backend/chunks/head', array(), TRUE) ?>
        <style>
            .tabs-left{

            }
            .my-fixed-item {
                position: fixed;
                min-height: 120px;
                width: 252px;
                text-align: right;
                word-wrap: break-word;
                /*background-color: aquamarine;*/
            }
            .tabs-left .nav-tabs{
                border-right: 1px solid #ddd;
                border-bottom: 0;
            }
            .tabs-left .nav {
                height: 100%;
                padding-bottom: 50%;
                padding-top: 5px;
            }
            .tabs-left .nav-tabs>li {
                float: left;
                width: 100%;
                margin-bottom: 2px;
            }
            .tabs-left .nav-tabs>li.active {
                border-left: solid 3px #3c8dbc;
            }
            .tabs-left .nav>li>a {

            }
            .tabs-left .nav-tabs>li>a:hover {
                border-color: #eee #ddd #eee #eee;
            }
            .tabs-left .nav>li>a:focus, .tabs-left .nav>li>a:hover {
                text-decoration: none;
                background-color: #eee;
            }
            .tabs-left .nav-tabs>li.active>a, .tabs-left .nav-tabs>li.active>a:focus, .tabs-left .nav-tabs>li.active>a:hover{
                border-color: #ddd;
                border-right-color: transparent;
                border-left: 0;
                background-color: #fff;
            }
            .tabs-left .nav-tabs>li>a {
                margin-right: -1px;
                border-radius: 0;
            }
            div.pull-right2{
                position: absolute;
                top: 10px;
                right: 30px;
            }
        </style>
    </head>
    <body class="hold-transition skin-add sidebar-mini">
        <div class="wrapper" style="width:100%;height:100%">
            <!-- Main Header -->
            <?= $this->load->view('backend/chunks/header', array(), TRUE) ?>
            <!-- Left side column. contains the logo and sidebar -->
            <?= $this->load->view('backend/chunks/sidebar', array(), TRUE) ?>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                
                <section class="content-header">
                    <h1>
                        <?= ($permiso['ver']==1) ? 'General' :''?>
                    </h1>
                </section>

                <!-- Main content -->
                <section class="content">
                    <?php if($permiso['ver']==1){?>
                    <div class="nav-tabs-custom" style="box-shadow: none;">
                        <ul class="nav nav-tabs">
                            <?php if (!empty($variables)) { ?>
                            <li class="active"><a href="#tab_variables" data-toggle="tab">Variables</a></li>
                            <?php } ?>
                            <?php if (!empty($tabs)) {
                                foreach ($tabs as $key => $tab) { ?>
                                    <li><a href="#tab_<?= clearString($tab['tabname']); ?>" data-toggle="tab"><?= $tab['tabname']; ?></a></li>
                            <?php }
                            } ?>
                        </ul>
                        <div class="tab-content">
                            <?php
                            if (!empty($categorias) && !empty($variables)) {
                                ?>
                                <div class="tab-pane active" id="tab_variables">
                                    <form id="inputs_variables" action="manager/general/guardar" method="post">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <div class="row tabs-left">
                                                    <div class="col-md-2 col-xs-12 pestanias">
                                                        <ul class="nav nav-tabs" role="tablist">
                                                            <?php
                                                            $i = 0;
                                                            foreach ($categorias as $key => $categoria) {
                                                                echo '<li role="presentation" class="' . (($i == 0) ? 'active' : '') . '"><a href="#tab_categoria_' . $categoria['idcontenedor'] . '" aria-controls="#tab_categoria_' . $categoria['idcontenedor'] . '" role="tab" data-toggle="tab">' . $categoria['contenedor'] . '</a></li>';
                                                                $i++;
                                                            } ?>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-10 col-xs-12">
                                                        <div class="tab-content">
                                                            <?php
                                                            $i = 0;
                                                            foreach ($categorias as $key => $categoria) {
                                                                echo '<div role="tabpanel" class="tab-pane ' . (($i == 0) ? 'active' : '') . '" id="tab_categoria_' . $categoria['idcontenedor'] . '">';
                                                                foreach ($variables as $variable) {
                                                                    if ($variable['idcontenedor'] == $categoria['idcontenedor']) {
                                                                        $datai = array(
                                                                            'variable' => $variable
                                                                        );
                                                                        switch ($variable['tipo']) {
                                                                            case 'data':
                                                                                echo $this->load->view('backend/inputs/data', $datai, TRUE);
                                                                                break;
                                                                            case 'datalibro':
                                                                                echo $this->load->view('backend/inputs/datalibro', $datai, TRUE);
                                                                                break;
                                                                            case 'hidden2':
                                                                                echo $this->load->view('backend/inputs/hidden2', $datai, TRUE);
                                                                                break;
                                                                            case 'selectlibro':
                                                                                echo $this->load->view('backend/inputs/selectlibro', $datai, TRUE);
                                                                                break;
                                                                            case 'selectcategoria':
                                                                                echo $this->load->view('backend/inputs/selectcategoria', $datai, TRUE);
                                                                                break;
                                                                            case 'datacuota':
                                                                                echo $this->load->view('backend/inputs/datacuota', $datai, TRUE);
                                                                                break;
                                                                            case 'richtext':
                                                                                echo $this->load->view('backend/inputs/richtext', $datai, TRUE);
                                                                                break;
                                                                            case 'textarea':
                                                                                echo $this->load->view('backend/inputs/textarea', $datai, TRUE);
                                                                                break;
                                                                            case 'image':
                                                                                echo $this->load->view('backend/inputs/image', $datai, TRUE);
                                                                                break;
                                                                            case 'imagejm':
                                                                                echo $this->load->view('backend/inputs/imagejm', $datai, TRUE);
                                                                                break;
                                                                            case 'textjm':
                                                                                echo $this->load->view('backend/inputs/textjm', $datai, TRUE);
                                                                                break;
                                                                            case 'imagejm2':
                                                                                echo $this->load->view('backend/inputs/imagejm2', $datai, TRUE);
                                                                                break;
                                                                            case 'textjm2':
                                                                                echo $this->load->view('backend/inputs/textjm2', $datai, TRUE);
                                                                                break;
                                                                            case 'radio':
                                                                                echo $this->load->view('backend/inputs/radio', $datai, TRUE);
                                                                                break;
                                                                            case 'select':
                                                                                echo $this->load->view('backend/inputs/select', $datai, TRUE);
                                                                                break;
                                                                            case 'hidden':
                                                                                echo $this->load->view('backend/inputs/hidden', $datai, TRUE);
                                                                                break;
                                                                            case 'multiselect':
                                                                                echo $this->load->view('backend/inputs/selectmultiple', $datai, TRUE);
                                                                                break;
                                                                            case 'file':
                                                                                echo $this->load->view('backend/inputs/file', $datai, TRUE);
                                                                                break;
                                                                            case 'video':
                                                                                echo $this->load->view('backend/inputs/video', $datai, TRUE);
                                                                                break;
                                                                            case 'colorpicker':
                                                                                echo $this->load->view('backend/inputs/colorpicker', $datai, TRUE);
                                                                                break;
                                                                            case 'checkbox':
                                                                                echo $this->load->view('backend/inputs/checkbox', $datai, TRUE);
                                                                                break;
                                                                            case 'radio':
                                                                                echo $this->load->view('backend/inputs/radio', $dataix, TRUE);
                                                                                break;
                                                                            case 'date':
                                                                                echo $this->load->view('backend/inputs/date', $datai, TRUE);
                                                                                break;
                                                                            default:
                                                                                echo $this->load->view('backend/inputs/text', $datai, TRUE);
                                                                                break;
                                                                        }
                                                                    }
                                                                }
                                                                echo '</div>';
                                                                $i++;
                                                            }
                                                            ?>
                                                        </div>
                                                        <!--<div style="height:150px;">-->
                                                        <!--</div>-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-12" style="padding-top:20px;">
                                                <button type="button" class="btn btn-warning btn-flat pull-right botonjm" style="margin-right:20px;"><i class="glyphicon glyphicon-share-alt"></i> Volver</button>
                                                <button type="submit" class="btn btn-primary btn-flat pull-right" style="margin-right:20px;"><i class="glyphicon glyphicon-floppy-disk"></i> Guardar</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <?php
                            }
                            ?>
                                <div class="tab-pane" id="tab_facebook">
                                <?php }else{?>
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h3 class="box-title"><strong>NO TIENES ACCESO A ESTE MÓDULO</strong></h3>
                                        <div class="box-tools pull-right">
                                          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
                                        </div>
                                    </div>
                                </div>
                                <?php }?>    
                            </section>
                            </div>
                            <?php
                            if (!empty($tabs)) {
                                foreach ($tabs as $key => $tab) {
                                    ?>
                                    <div class="tab-pane" id="tab_<?= clearString($tab['tabname']); ?>">
                                        <?= $this->load->view($tab['tabview'], array(), TRUE); ?>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                            <?= $this->load->view('backend/chunks/footer', array(), TRUE) ?>
                        </div>
                <!-- /.content -->
            <!-- /.content-wrapper -->

            <!-- Main Footer -->
            
        <!-- ./wrapper -->

        <?= $this->load->view('backend/chunks/modalLoading', array(), TRUE) ?>

        <!-- REQUIRED JS SCRIPTS -->
        <?= $this->load->view('backend/chunks/scripts', array(), TRUE) ?>
        
        <?php
        if (!empty($tabs)) {
            foreach ($tabs as $key => $tab) {
                if (isset($tab['tabcss']) && !empty($tab['tabcss'])) {
                    echo '<link type="text/css" href="' . $tab['tabcss'] . '" rel="stylesheet" property="stylesheet">';
                }

                if (isset($tab['tabjs']) && !empty($tab['tabjs'])) {
                    echo '<script type="text/javascript" src="' . getFilex($tab['tabjs']) . '"></script>';
                    echo '<script type="text/javascript">';
                    echo '$(document).ready(function(){Exeperu.tab_' . clearString($tab['tabname'], '_') . '(\'' . $this->config->item('akey') . '\', ' . (isset($tab['idtipo']) ? $tab['idtipo'] : '') . ');});';
                    echo '</script>';
                }
            }
        }
        ?> 
        <script>
            $(document).ready(function () {
                $('.tabs-left a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                    var tab_content = $(e.target.hash);
                    var tab_content_height = tab_content.height();

                    $(e.target).parents('div.pestanias').css({height: tab_content_height});
                });
                
                $(".my-colorpicker1").colorpicker();
                
                $(".botonjm").click(function(e){
                   e.preventDefault();
                   window.location.href="manager/general";
                });
                
                $("#inputs_variables").submit(function(e){
                  e.preventDefault();
                  $.ajax({
                      url:$(this).attr('action'),
                      type:$(this).attr('method'),
                      data:$(this).serialize(),
                      success:function(response){
                        var jm=JSON.parse(response);
                        toastr.success(jm.mensaje,{timeOut:2000});
                        setTimeout("location.href='manager/general'", 2000);
                      }
                  });
                });
            });
        </script>
    </body>
</html> 