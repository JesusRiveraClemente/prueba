<!DOCTYPE html>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <?php echo $this->load->view('backend/chunks/head', '', TRUE); ?>
    </head>
    <body class="hold-transition skin-add sidebar-mini" >
        <div class="wrapper">
            <?php
            echo $this->load->view('backend/chunks/header', '', TRUE);

            echo $this->load->view('backend/chunks/sidebar', array('active' => ''), TRUE);
            ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Dashboard  Metodo Password: <?php echo password_hash("lavida123", PASSWORD_DEFAULT)."\n"; ?>
                    </h1>
                </section>

                <!-- Main content -->
                <section class="content">
                  <div class="row">

                        <!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                          <div class="small-box bg-yellow">
                            <div class="inner">
                              <h3><?= $cantidad_planes; ?></h3>

                              <p>Planes de Estudios</p>
                            </div>
                            <div class="icon">
                              <i class="ion-ribbon-b"></i>
                            </div>
                          </div>
                        </div>

                        <!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                          <div class="small-box bg-blue">
                            <div class="inner">
                              <h3><?= $cantidad_beneficios; ?></h3>

                              <p>Beneficios</p>
                            </div>
                            <div class="icon">
                              <i class="ion-ribbon-b"></i>
                            </div>
                          </div>
                        </div>

                        <!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                          <div class="small-box bg-green">
                            <div class="inner">
                              <h3><?= $cantidad_eventos; ?></h3>

                              <p>Nuestros Eventos</p>
                            </div>
                            <div class="icon">
                              <i class="ion-ribbon-b"></i>
                            </div>
                          </div>
                        </div>

                  </div>
                </section>
                
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->

            <?php
            echo $this->load->view('backend/chunks/footer', '', TRUE);

//            if ($user['manager']['sudo']) {
//                echo $this->load->view('backend/chunks/content-sidebar-sudo', '', TRUE);
//            }
            ?>
        </div>
        <!-- ./wrapper -->

        <?php echo $this->load->view('backend/chunks/scripts', '', TRUE); ?>

        <script>
            $(document).ready(function () {

            });
        </script>
    </body>
</html>