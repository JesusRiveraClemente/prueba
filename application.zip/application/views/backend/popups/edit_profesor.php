<div class="modal-dialog modal-lg" role="document">
  <form id="formCrearEditarautor" action="manager/equipo/save" method="POST">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4><strong>Profesor</strong></h4>
            <style>
                .form-group.required .control-label:after {
                        color: #d00;
                        content: "*";
                        position: absolute;
                        margin-left: 8px;
                        top:2px;
                  }
            </style>
        </div>
        <div class="modal-body">
            <ul class="nav nav-tabs" role="tablist" style="margin-bottom: 15px;" id="tabs">
                <li role="presentation" class="active">
                    <a href="#sprincipal" aria-controls="principal" role="tab" data-toggle="tab">Principal</a>
                </li>           
            </ul>
            <div class="tab-content">
                <!-- NUMERO 1 -->
                <div role="tabpanel" class="tab-pane active" id="sprincipal">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xs-12 col-md-12">
                                <div class="form-group required">
                                    <label class="control-label">Codigo</label>
                                    <input type="text" id="codigo" class="form-control" name="profesores[codigo]" placeholder="Ingrese el codigo del profesor" value="<?= isset($profesor['codigo']) ? $profesor['codigo'] : ''; ?>" >
                                </div>
                            </div>
                            <div class="col-xs-12 col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Nombres</label>
                                    <input type="text" id="nombres" class="form-control" name="profesores[nombres]" placeholder="Ingrese los nombres del profesor" value="<?= isset($profesor['nombres']) ? $profesor['nombres'] : ''; ?>" >
                                </div>
                            </div>
                            <div class="col-xs-12 col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Apellidos</label>
                                    <input type="text" id="apellidos" class="form-control" name="profesores[apellidos]" placeholder="Ingrese los apellidos del profesor" value="<?= isset($profesor['apellidos']) ? $profesor['apellidos'] : ''; ?>" >
                                </div>
                            </div>
                            <!-- <div class="col-xs-12 col-md-12">
                                <div class="form-group required">
                                    <label class="control-label">Fecha de Nacimiento</label>
                                    <input type="date" id="fecha_nacimiento" class="form-control" name="profesores[fecha_nacimiento]" placeholder="Ingrese la fecha de nacimiento del profesor" value="<?= isset($profesor['fecha_nacimiento']) ? $profesor['fecha_nacimiento'] : ''; ?>" >
                                </div>
                            </div> -->
                            <div class="col-xs-12 col-md-4">
                                <div class="form-group required">
                                    <label class="control-label">Dni</label>
                                    <input type="text" id="dni" class="form-control" name="profesores[dni]" placeholder="Ingrese el dni del profesor" value="<?= isset($profesor['dni']) ? $profesor['dni'] : ''; ?>" >
                                </div>
                            </div>
                            <div class="col-xs-12 col-md-4">
                                <div class="form-group">
                                    <label for="campo_3-1" class="control-label">Sexo</label>
                                    <select name="profesores[sexo]" id="sexo" class="form-control">
                                        <option value="M" <?= ($profesor['sexo'] == "M" ? 'selected' : '') ?>>Masculino</option>
                                        <option value="F" <?= ($profesor['sexo'] == "F" ? 'selected' : '') ?>>Femenino</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xs-12 col-md-4">
                                <div class="form-group">
                                    <label class="control-label">Telefono</label>
                                    <input type="text" id="telefono" class="form-control" name="profesores[telefono]" placeholder="Ingrese el telefono del profesor" value="<?= isset($profesor['telefono']) ? $profesor['telefono'] : ''; ?>" >
                                </div>
                            </div>
                            <div class="col-xs-12 col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Direccion</label>
                                    <input type="text" id="direccion" class="form-control" name="profesores[direccion]" placeholder="Ingrese el direccion del profesor" value="<?= isset($profesor['direccion']) ? $profesor['direccion'] : ''; ?>" >
                                </div>
                            </div>
                            <div class="col-xs-12 col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Email</label>
                                    <input type="text" id="email" class="form-control" name="profesores[email]" placeholder="Ingrese el email del profesor" value="<?= isset($profesor['email']) ? $profesor['email'] : ''; ?>" >
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label class="control-label">Orden</label>
                                    <input type="text" id="orden" class="form-control" name="profesores[orden]" placeholder="Ingrese el Orden" value="<?= isset($profesor['orden']) ? $profesor['orden'] : ''; ?>" >
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label for="campo_3-1" class="control-label">Estado</label>
                                    <select name="profesores[estado]" id="estado" class="form-control">
                                        <option value="1" <?= ($profesor['estado'] == 1 ? 'selected' : '') ?>>Activo</option>
                                        <option value="0" <?= ($profesor['estado'] == 0 ? 'selected' : '') ?>>Inactivo</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>  
                </div>
                
            </div>      
        </div>
        <div class="modal-footer">
            <button type="reset" class="btn btn-default btn-flat" data-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary btn-flat">Guardar</button>
        </div>
        <input type="hidden" id="ids" name="profesores[idprofesor]" value="<?= isset($profesor['idprofesor']) ? $profesor['idprofesor'] : '';?>">
    </div>
  </form>

<script>
    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();

        Exeperu.key = '<?= $this->config->item('akey') ?>';
        Exeperu.tinyInit('<?= $this->config->item('akey'); ?>');

        $("#formCrearEditarautor").submit(function(e){
           e.preventDefault();
           $.ajax({
              url: $(this).attr('action'),
              type:$(this).attr('method'),
              data:$(this).serialize(),
              success:function(response){
                    var jm=JSON.parse(response);
                    if(jm.tipo==1){
                        toastr.success(jm.mensaje,{timeOut:2000});
                        Exeperu.reloadTableProfesores();
                    }else{
                        toastr.error(jm.mensaje,{timeOut:2000});
                        var errores=JSON.parse(jm.errores); 
                        $.each( errores, function( key, value ) {
                            $("#"+value+"").parent().addClass("has-error");
                            if(value=='campo_4'){
                                $("#"+value+"").parent().parent().addClass("has-error");
                            }
                        });
                        var jmjm=JSON.parse(jm.jm); 
                        $.each( jmjm, function( key, value ) {
                            $("#"+value+"").parent().removeClass();
                        });
                    }
                  }
               });
            });
        });
</script>
</div>