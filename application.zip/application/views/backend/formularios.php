<!DOCTYPE html>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <?= $this->load->view('backend/chunks/head', array(), TRUE) ?>
    </head>
    <body class="hold-transition skin-add sidebar-mini">
        <div class="wrapper">
            <!-- Main Header -->
            <?= $this->load->view('backend/chunks/header', array(), TRUE) ?>
            <!-- Left side column. contains the logo and sidebar -->
            <?= $this->load->view('backend/chunks/sidebar', array(), TRUE) ?>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->

                <section class="content-header"> 
                    <?php if($permiso['ver']==1){?>
                    <h1>
                        Administrador de Formularios
                    </h1>
                    <?php }?>
                </section>

                <!-- Main content -->
                <section class="content container-fluid">
                    <?php if($permiso['ver']==1){?>
                    <div class="box box-add">
                        <div class="box-header with-border">
                            <!--<h3 class="box-title">Filtrar</h3>-->
                            <div class="container">
                                
                            </div>
                        </div>
                        <div class="box-body">  
                            <div class="nav-tabs-custom">
                                <a class="btn bg-olive btn-flat margin" onclick="doit(&#39;xlsx&#39;);">DESCARGAR EXCEL</a>
                            </div>
                            <div class="nav-tabs-custom">
                                <table border="2" id="table_formularios" class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <th>
                                            <th style="display: none;" colspan="6">Registros</th>
                                            <th style="display: none;" colspan="2">
                                                Fecha: 
                                                <?php date_default_timezone_set('America/Lima'); ?>
                                                <?= date("h:i"." "."d-m-y"); ?>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th>Id</th>                                            
                                            <th>Formulario</th>
                                            <th>Nombres</th>
                                            <th>Telefono</th>
                                            <th>email</th>
                                            <th>fecha</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php }else{?>
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><strong>NO TIENES ACCESO A ESTE MÓDULO</strong></h3>

                            <div class="box-tools pull-right">
                              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
                            </div>
                        </div>
                    </div>
                    <?php }?>
                </section>

                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->

            <!-- Main Footer -->
            <?= $this->load->view('backend/chunks/footer', array(), TRUE) ?>
        </div>
        <!-- ./wrapper -->

        <?= $this->load->view('backend/chunks/modalLoading', array(), TRUE) ?>

        <!-- REQUIRED JS SCRIPTS -->
        <?= $this->load->view('backend/chunks/scripts', array(), TRUE) ?>

        <script src="<?= getFilex('mgr/exeperu/js/formularios.js') ?>"></script>

        <script>
            $(document).ready(function () {
                Exeperu.init({
                    'url': 'manager/formularios/read'
                });
//                toastr.success('Registrado correctamente',{timeOut:3000});
            });
            
            // Excel
            function doit(type, fn, dl) {
              var elt = document.getElementById('table_formularios');
              var wb = XLSX.utils.table_to_book(elt, {sheet:"Sheet JS"});
              return dl ?
                XLSX.write(wb, {bookType:type, bookSST:true, type: 'base64'}) :
                XLSX.writeFile(wb, fn || ('Con Amor - Formularios.' + (type || 'xlsx')));
            }
            
        </script>
    </body>
</html>