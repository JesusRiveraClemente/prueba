<!DOCTYPE html>
<html lang="es" id="inicio">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php
        $pagetitle = $pagina['pagetitle'];
        $meta_description = $pagina['meta_description'];
        $meta_keyword = $pagina['meta_keyword'];
        
        $og_url = $pagina['og_url'];
        $og_title = $pagina['og_title'];
        $og_description = $pagina['og_description'];
        $og_image = $pagina['og_image'];
    ?>
    <?php include 'chunks/head.php'; ?>
</head>
<body>
    <?php include 'chunks/header-nav.php'; ?>

<section class="pd-all"></section>


    <?php include 'chunks/footer.php'; ?>
    <?php include 'chunks/script.php'; ?>

    <script>
        $(document).ready(function () {
            
        });
        $(window).on('load', function() {

        });
    </script>
</body>
</html>