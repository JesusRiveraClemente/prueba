<!DOCTYPE html>
<html lang="es" id="inicio">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php
        $pagetitle = "ColegioPro | Matricular";
        $meta_description = "";
        $meta_keyword = "";
    ?>
    <?php include 'chunks/head.php'; ?>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="mx-auto" href="">
    <img src="assets/sources/empresa/esolutiontech-logo.png">
  </div>
</nav>


<section class="pd-all"></section>

<section class="solicitar-vacante formulario pd-all">
    <div class="container">
        <form method="POST" id="form-matricular" class="form" action="send/matricular">
            <input type="hidden" name="matriculas[codigo]" value="001">
            <input type="hidden" name="alumnos[idapoderado]" value="1">
            <div class="row">
                <div class="col-md-12">
                    <div>
                        <h1 class="black text-center">MATRICULAR</h1>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">                    
                        <input type="text" class="form-control" name="alumnos[nombres]"  placeholder="Nombres">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">                    
                        <input type="text" class="form-control" name="alumnos[apellidos]"  placeholder="Apellidos">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <input type="text" class="form-control" name="alumnos[dni]"  placeholder="Dni">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <select class="form-control" name="alumnos[sexo]">
                            <option value="">Seleccionar Sexo:</option>
                            <option value="M">Masculino</option>
                            <option value="F">Femenino</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <input type="date" class="form-control" name="alumnos[fecha_nacimiento]"  placeholder="Fecha de Nacimiento">
                    </div>
                </div>
                <div class="col-md-6">
                    <div  class="form-group">
                        <input type="text" class="form-control" name="alumnos[telefono]"  placeholder="Teléfono" maxlength="9" onkeypress="if ( isNaN( String.fromCharCode(event.keyCode) )) return false;">
                    </div>
                </div>
                <div class="col-md-6">
                    <div  class="form-group">
                        <input type="text" class="form-control" name="alumnos[direccion]"  placeholder="Direccion">
                    </div>
                </div>
                <div class="col-md-6">
                    <div  class="form-group">
                        <input type="text" class="form-control" name="alumnos[email]"  placeholder="Email">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="cont-button text-center">
                        <button type="submit" class="button-ver">ENVIAR</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<section class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12 info">
                <span>ColegioPro 2020 - Todos los derechos reservados</span>
                <span> Diseñado por JRC WEB</span>
             </div>
        </div>
    </div>
 </section>

    <?php include 'chunks/script.php'; ?>

    <script>
        $(document).ready(function () {
            
        });
        $(window).on('load', function() {

        });
    </script>
</body>
</html>