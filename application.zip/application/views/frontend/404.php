<!DOCTYPE html>
<html lang="es" id="inicio">
<head>
    <?php
        $pagetitle = "Error 404";
        $meta_description = "";
        $meta_keyword = "";
        
        $og_url = "";
        $og_title = "";
        $og_description = "";
        $og_image = "";
    ?>
    <?php include 'chunks/head.php'; ?>
</head>
<body>
<style>
    .btnBack{
        padding: 10px 20px;
        border: 2px solid;
        border-color: var(--colorbase1);
        color: var(--colorbase1);
        background: transparent;
        margin: 15px;
        transition: border 0.7s;
    }
    .btnBack:hover{
        background: var(--colorbase1);
        color: #fff;
        cursor: pointer;
        border-color: #fff;
        transition: border 0.7s;
    }
</style>
    <a href="<?php echo base_url(); ?>" style="padding: 10px;margin: 10px;position: absolute;top: 0;left: 0"><img src="<?= $empresa['logo'] ?>"></a>
    <div style="width: 100%;height: 100%">
        <div style="display: flex;justify-content: center;align-items: center;height: 500px;flex-direction: column">
            <h1 style="color: var(--colorbase1);font-size: 5rem;margin: 0">404</h1>
            <hr style="width: 80%;border-color: var(--colorbase1)">
            <h3 style="color: var(--colorbase1);font-size: 30px">Not Found</h3>
            <p style="color: var(--colorbase1); font-size: 25px;margin: 0 20px;text-align: center">The resource requested could not be found on this server!</p>
            <buttom onclick="window.history.back();" class="btnBack">Volver</buttom>
        </div>
    </div>
</body>
</html>