<!DOCTYPE html>
<html lang="es" id="inicio">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php
        $pagetitle = $pagina['pagetitle'];
        $meta_description = $pagina['meta_description'];
        $meta_keyword = $pagina['meta_keyword'];
        
        $og_url = $pagina['og_url'];
        $og_title = $pagina['og_title'];
        $og_description = $pagina['og_description'];
        $og_image = $pagina['og_image'];
    ?>
    <?php include 'chunks/head.php'; ?>
</head>
<body>
    <?php include 'chunks/header-nav.php'; ?>

<style>
    section.plan-detalle.banner{
        background: url(<?= $pagina['banner'] ?>);
        background-size: cover;
        background-position: bottom center;
        filter: saturate(2);
    }
    section.plan-detalle.banner .head h1{
        font-family: var(--fontlight);
        text-align: center;
        font-size: 42px;
        font-weight: bolder;
        margin: 0;
    }
</style>
<section class="pd-all"></section>

<section class="plan-detalle banner pd-all" data-aos="fade-up">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <h1 class="title white text-center text-uppercase title"><?= $pagina['titulo'] ?></h1>
                <p class="description white text-center"><?= $pagina['descripcion'] ?></p>
            </div>
        </div>
    </div>
</section>
<style type="text/css">
    section.plan-detalle.contenido .footer .ctnSolicitar{
        background: var(--colorbase3);
        width: 100%;
        border-radius: var(--borderradiusctn);
        padding: 30px 20px;
        transition: all 0.4s;
    }
    section.plan-detalle.contenido .footer .ctnSolicitar:hover{
        box-shadow: 8px 8px 0px 0px #ccc;
        transition: all 0.4s;
    }
    section.plan-detalle.contenido .footer .ctnSolicitar .ctnHead h4{
        font-size: 35px;
    }
    section.plan-detalle.contenido .footer .ctnSolicitar .ctnBody p{
        font-size: 15px;
    }
    section.plan-detalle.contenido .footer .ctnSolicitar .ctnFooter a{
        font-size: 20px;
        padding: var(--paddingbtn);
        border-radius: var(--borderradiusbtn);
        background: var(--colorbase6);
        display: inline-block;
        color: #000;
    }
</style>

<section class="plan-detalle contenido pd-all" data-aos="fade-up">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-lg-8 body">
                <?= $pagina['contenido'] ?>
            </div>
            <div class="col-xs-12 col-lg-4 footer text-center">
                <div class="ctnSolicitar">
                    <div class="ctnHead text-center">
                        <h4>RESERVA TU VACANTE</h4>
                    </div>
                    <div class="ctnBody text-center">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodoconsequat.</p>
                    </div>
                    <br>
                    <div class="ctnFooter text-center">
                        <a href="solicitar-vacante">Solicitar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="plan-detalle galeria pd-all" data-aos="fade-up">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <h1 class="title white text-center text-uppercase title"></h1>
                <p class="description white text-center"></p>
            </div>
        </div>
    </div>
</section>

    <?php include 'chunks/footer.php'; ?>
    <?php include 'chunks/script.php'; ?>

    <script>
        $(document).ready(function () {
            
        });
        $(window).on('load', function() {
            
        });
    </script>
</body>
</html>
