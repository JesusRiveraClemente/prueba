<style type="text/css">
    /* Slider */
      .tparrows{
        background: var(--controllerswy);
        width: 41px;
        height: 148px;
        transform: unset !important;
        left: unset !important;
        display: none;
        margin: 0 20px;
      }

      .tparrows.tp-leftarrow{
        background-position: 0 0;
        left: 0 !important;
        transition: left 0.4s;
      }
      .tparrows.tp-leftarrow:hover{
        background-position: 0 -148px;
      }
      .tparrows.tp-rightarrow{
        background-position: -41px 0;
        right: 0 !important;
        transition: right 0.4s;
      }
      .tparrows.tp-rightarrow:hover{
        background-position: -41px -148px;
      }
      .tparrows.tp-rightarrow:before,.tparrows.tp-leftarrow:before{
        content: unset;
      }
      @media(min-width: 576px){
        .tparrows{
          display: block;
          top: 46% !important;
        }
      }
      @media(min-width: 768px){
        .tparrows.tp-leftarrow{
          left: 10% !important;
        }
        .tparrows.tp-rightarrow{
          right: 10% !important;
        }
      }
      @media(min-width: 768px){
        .tparrows.tp-leftarrow{
          left: 5% !important;
        }
        .tparrows.tp-rightarrow{
          right: 5% !important;
        }
      }


      /* Dots Controllers */
        .tp-bullet{
          width: 22px;
          height: 19px;
          position: unset;
          margin: 2px;
          background: var(--colorbase6);
          border-radius: 50px;
          /*background: var(--controllerslider);*/
          background-position: 0 0;
        }
        .tp-bullet.selected, .tp-bullet:hover{
          background: var(--colorbase3);
          /*background: var(--controllerslider);*/
          background-position: 0 -19px;
        }

        .tp-tabs, .tp-thumbs, .tp-bullets{
          top: 94% !important;
          width: 100% !important;
          text-align: center;
          left: 0 !important;
          display: flex;
          justify-content: center;
          transform: unset !important;
        }
      /* End Dots Controllers */
    /* End Slider */
</style>

<main id="page-content" class="l-main" itemprop="mainContentOfPage">
    <section class="l-section wpb_row height_auto width_full color_alternate">
        <div class="l-section-h i-cf">
            <div class="g-cols vc_row type_default valign_top">
                <div class="vc_col-sm-12 wpb_column vc_column_container">
                    <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                            <div class="wpb_revslider_element wpb_content_element">
                                <p class="rs-p-wp-fix"></p>
                                <rs-module-wrap id="rev_slider_4_1_wrapper" data-source="gallery" style="background:transparent;padding:0;">
                                    <rs-module id="rev_slider_4_1" style="display:none;" data-version="6.0.9">
                                        <rs-slides>
                                            <?php $cont = 1; ?>
                                            <?php foreach ($contenido['banner'] as $slide): ?>
                                                <rs-slide data-key="rs-<?= $cont++ ?>" data-title="Slide" data-thumb="" data-anim="ei:d;eo:d;s:d;r:0;t:slidingoverlayright;sl:d;">
                                                    <img src="<?= $slide['item_fondo'] ?>" title="Home" data-lazyload="<?= $slide['item_fondo'] ?>" data-bg="p:right bottom;" data-parallax="20" class="rev-slidebg" data-no-retina>
                                                    
                                                    <rs-layer id="slider-4-slide-21-layer-6" class="Gym-Display tituloSlider" data-type="text" data-rsp_ch="off" data-xy="xo:150px;yo:195px;" data-text="s:80;l:100;fw:900;" data-frame_0="x:-175%;o:1;tp:600;" data-frame_0_mask="u:t;x:100%;" data-frame_1="tp:200;e:Power3.easeOut;st:0;sp:5000;" data-frame_1_mask="u:t;" data-frame_999="o:0;tp:600;e:nothing;st:w;sR:6000;" style="z-index:5;font-family:open sans;">
                                                        <img src="<?= $slide['item_titulo'] ?>" class="img-fluid" data-lazyload="<?= $slide['item_titulo'] ?>">
                                                    </rs-layer>

                                                    <rs-layer id="slider-4-slide-21-layer-7" class="Gym-SmallText rs-layer textoSlider" data-type="text" data-color="rgba(255, 255, 255, 1)" data-rsp_ch="on" data-xy="xo:150px;yo:325px;" data-text="w:normal;s:24;l:34;fw:bold;" data-dim="w:450px" data-layeronlimit="on" data-frame_0="y:100%;tp:400;" data-frame_1="tp:600;e:Power4.easeInOut;sp:3000;" data-frame_999="o:0;tp:400;e:nothing;st:w;sR:5000;" style="z-index:6;font-family:Open Sans;text-shadow:none;">
                                                        <p><?= $slide['item_texto'] ?></p>
                                                    </rs-layer>

                                                    <rs-layer id="slider-4-slide-21-layer-7" class="Gym-SmallText rs-layer btnVerDetalles" data-type="text" data-color="rgba(255, 255, 255, 1)" data-rsp_ch="on" data-xy="xo:150px;yo:380px;" data-text="w:normal;s:24;l:34;fw:bold;" data-dim="w:450px" data-layeronlimit="on" data-frame_0="y:100%;tp:400;" data-frame_1="tp:600;e:Power4.easeInOut;sp:3000;" data-frame_999="o:0;tp:400;e:nothing;st:w;sR:5000;" style="z-index:6;font-family:Open Sans;text-shadow:none;">
                                                        <a href="<?= $slide['item_url_bottom'] ?>">
                                                            <?= $slide['item_texto_bottom'] ?>
                                                        </a>
                                                    </rs-layer>

                                                    <rs-layer class="imagenProductoSlider" id="slider-4-slide-21-layer-10" data-type="image" data-rsp_ch="on" data-xy="xo:830px;yo:190px;" data-text="l:22;" data-dim="w:['380px','380px','380px','380px'];h:['292px','292px','292px','292px'];" data-frame_0="y:100%;tp:600;" data-frame_1="tp:600;e:Power4.easeInOut;st:0;sp:2500;" data-frame_999="o:0;tp:600;e:nothing;st:w;sR:5500;" style="z-index:7;">
                                                        <img src="<?= $slide['item_producto'] ?>" class="img-fluid" data-lazyload="<?= $slide['item_producto'] ?>" style="width: unset !important;" data-no-retina>
                                                    </rs-layer>
                                                    
                                                    <rs-layer class="imagenTecladoSlider" id="slider-4-slide-21-layer-10" data-type="image" data-rsp_ch="on" data-xy="xo:830px;yo:190px;" data-text="l:22;" data-dim="w:['380px','380px','380px','380px'];h:['292px','292px','292px','292px'];" data-frame_0="y:100%;tp:600;" data-frame_1="tp:600;e:Power4.easeInOut;st:0;sp:2500;" data-frame_999="o:0;tp:600;e:nothing;st:w;sR:5500;" style="z-index:0;">
                                                        <img src="assets/sources/01-home/banner/teclado.png" class="img-fluid" data-lazyload="<assets/sources/01-home/banner/teclado.png" style="width: unset !important;" data-no-retina>
                                                    </rs-layer>

                                                    <rs-layer class="imagenMouseSlider" id="slider-4-slide-21-layer-10" data-type="image" data-rsp_ch="on" data-xy="xo:830px;yo:190px;" data-text="l:22;" data-dim="w:['380px','380px','380px','380px'];h:['292px','292px','292px','292px'];" data-frame_0="y:100%;tp:600;" data-frame_1="tp:600;e:Power4.easeInOut;st:0;sp:2500;" data-frame_999="o:0;tp:600;e:nothing;st:w;sR:5500;" style="z-index:0;">
                                                        <img src="assets/sources/01-home/banner/mouse.png" class="img-fluid" data-lazyload="assets/sources/01-home/banner/mouse.png" style="width: unset !important;" data-no-retina>
                                                    </rs-layer>

                                                </rs-slide>
                                            <?php endforeach ?>
                                        </rs-slides>
                                        <rs-progress class="rs-bottom" style="height: 5px; background: rgba(255,255,255,0.20);"></rs-progress>
                                    </rs-module>
                                </rs-module-wrap>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>