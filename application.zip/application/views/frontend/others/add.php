<?php 
	if( $pagina['pagina'] == 'Home' ){            
		$proyectos_carrusel = array();
		foreach ($data['distritos'] as $dist) {
			$proyectos_carrusel[$dist['iddistrito']] = $this->contenido->getProyectos($dist['iddistrito']);
		}
		$data['proyectos_carrusel'] = $proyectos_carrusel;
	}
?>