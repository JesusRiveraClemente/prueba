<meta charset="utf-8">
<title><?= isset($pagetitle) ? $pagetitle : '' ?></title>
<base href="<?= $this->config->base_url(); ?>">
<meta name="description" content="<?= isset($meta_description) ? $meta_description : '' ?>" />
<meta name="keywords" content="<?= isset($meta_keyword) ? $meta_keyword : '' ?>" />
<meta name="author" content="BUDA.PE MARKETING DIGITAL INTEGRADO" />
<meta name="copyright" content="" />
<meta name="language" content="ES" />
<meta name="robots" content="index,follow" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="theme-color" content="#fff"/>
<meta name="msapplication-navbutton-color" content="#fff"/>
<link rel="shortcut icon" href="<?= $empresa['favicon'] ?>?<?= date('YmdHis'); ?>">

<!-- Facebook -->
<meta property="fb:app_id" content="" />
<meta property="og:url" content="<?= isset($og_url) ? $og_url : '' ?>" />
<meta property="og:site_name" content="Con Amor" />
<meta property="og:type" content="website" /><!-- website | article | book | profile -->
<meta property="og:title" content="<?= isset($og_title) ? $og_title : '' ?>" />
<meta property="og:description" content="<?= isset($og_description) ? $og_description : '' ?>" />
<meta property="og:image" content="<?= isset($og_image) ? $og_image : '' ?>" />
<meta property="og:image:type" content="image/jpg" /><!-- image/jpeg -->
<meta property="og:image:url" content="" />
<meta property="og:image:alt" content="" />
<meta property="og:image:width" content="400" />
<meta property="og:image:height" content="400" />


<!-- Bootstrap -->
<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css" property="stylesheet">

<!-- Slick -->
<link rel="stylesheet" type="text/css" href="assets/slick/css/slick.css" />

<!-- Aos -->
<link href="assets/aos/css/aos.css" rel="stylesheet">

<!-- Rs6 -->
<link href='assets/themepunch-tools/css/rs6.css' rel='stylesheet' type='text/css' media='all' id='rs-plugin-settings-css' />

<!-- Fancybox -->
<link href="assets/fancybox/css/jquery.fancybox.min.css" rel="stylesheet">

<!-- SmartSlider -->
<link rel="stylesheet" type="text/css" href="assets/smartslider/css/smartslider.min.css?1570105445" media="all" />

<!-- Css -->
<link rel="stylesheet" type="text/css" href="assets/css/colegiopro.css?<?= date('YmdHis'); ?>" property="stylesheet">

<?= isset($empresa['headertop']) ? $empresa['headertop'] : '' ?>

<!-- Google Analytics -->
<script type="text/javascript">
    <?= isset($empresa['googleanalytics']) ? $empresa['googleanalytics'] : '' ?>
</script>
<!-- /Google Analytics -->

<!-- Facebook Pixel -->
<script type="text/javascript">
    <?= isset($empresa['facebookpixel']) ? $empresa['facebookpixel'] : '' ?>
</script>
<!-- /Facebook Pixel -->

<?= isset($empresa['headerbottom']) ? $empresa['headerbottom'] : '' ?>
