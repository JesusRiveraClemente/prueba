<a class="acotiza" style="display: none;" data-fancybox data-src="#cotiza_aqui" href="javascript:;">COTIZA AQUI</a>

<div style="display: none;" class="hidden-content" id="cotiza_aqui">
  <h2 class="title2-box text-center">COTIZA TU DEPA</h2>
  <div class="p-prin1"><p>Envianos tus datos, gustosamente nuestro equipo de asesores te atendera a la brevedad</p></div>
  <div class="">
    <form method="POST" id="form-cotiza-head" class="formulario" onsubmit="return false;">
      <div class="form-group">
        <select class="form-control" name="proyecto">
          <option >Seleccione un Proyecto</option>
          <?php foreach ($servicios as $item): ?>
            <option value="<?= $item['id'] ?>"><?= $item['titulo']  ?></option>
          <?php endforeach ?>
        </select> 
      </div>
      <div class="form-group">                    
        <input type="text" class="form-control" name="nombres"  placeholder="Nombres y Apellidos">                    
      </div>
      <div class="form-group">                    
        <input type="text" class="form-control" name="dni"  placeholder="DNI" maxlength="8">                    
      </div>
      <div class="form-group">                    
        <input type="text" class="form-control" name="telefono"  placeholder="Teléfono">                    
      </div>
      <div class="form-group">                    
        <input type="text" class="form-control" name="email"  placeholder="Email">                    
      </div>
      <div class="form-group">                    
        <textarea rows="4" class="form-control" name="mensaje" placeholder="Mensaje"></textarea>                 
      </div>
      <input type="hidden" name="formulario" value="cotiza aqui">
      <div class="cont-button text-center">
        <button class="button-ver">ENVIAR</button>
      </div>
    </form>
  </div>
</div>

<a class="apopup" data-fancybox data-src="#pop-up" href="javascript:;" style="display: none"></a>
    <div style="display: none;" class="hidden-content" id="pop-up">
        <form method="POST" id="form-popup" class="formulario form" action="send/popup">
            <center class="img_popup"><img src="<?= $contenido['popup_image'] ?>" alt="logo" ></center>
            <center class="tit_popup" ><img src="<?= $contenido['popup_title_image'] ?>"></center>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">                    
                        <input type="text" class="form-control" name="nombres"  placeholder="Nombres y Apellidos">                    
                    </div>
                    <div  class="form-group">
                        <input type="text" class="form-control" name="telefono"  placeholder="Teléfono" maxlength="9" onkeypress="if ( isNaN( String.fromCharCode(event.keyCode) )) return false;">
                    </div>
                </div>
                <div class="col-md-6">
                    <div  class="form-group">
                        <select class="form-control" name="servicio">
                            <option value="">Seleccionar</option>
                            <?php foreach ($servicios as $item): ?>
                            <option value="<?= clearString($item['titulo']) ?>"><?= $item['titulo']  ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <div  class="form-group">
                        <input type="text" class="form-control" name="email"  placeholder="Email">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="cont-button text-center">
                        <button type="submit" class="button-ver">ENVIAR</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <script>
        $(".acotiza").fancybox().trigger('click');
    </script>
