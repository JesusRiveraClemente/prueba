<!-- Jcarousel -->
<script src="assets/jcarousel/js/jcarousel.js" type="33-text/javascript"></script>

<!-- Cloud Zoom -->
<script src="assets/cloud-zoom/js/cloud-zoom.js" type="33-text/javascript"></script>

<!-- Rocket Loader -->
<script src="assets/cloudflare/js/rocket-loader.min.js" data-cf-settings="33-|49" defer=""></script>

<!-- JQuery -->
<script src="assets/jquery/jquery.min.js"></script>
<!-- <script src="assets/jquery/jquery.slim.min.js"></script> -->
<!-- <script src='assets/jquery/jquery.js'></script> -->

<!-- Slick -->
<script src="assets/slick/js/slick.min.js"></script>

<!-- Themepunch Tools -->
<script src='assets/themepunch-tools/js/revolution.tools.min.js'></script>
<script src='assets/themepunch-tools/js/rs6.min.js'></script>

<!-- Bootstrap -->
<script type="33-text/javascript" src="assets/bootstrap/js/bootstrap.js"></script>

<!-- Aos -->
<script src="assets/aos/js/aos.js"></script>

<!-- Fancybox  -->
<script src="assets/fancybox/js/jquery.fancybox.min.js"></script>

<!-- Validate -->
<script type="text/javascript" src="assets/validate/js/jquery.validate.min.js"></script>

<!-- Js -->
<script src="assets/js/esolutiontech.js?<?= date('YmdHis'); ?>"></script>
<script src="assets/js/scripthead.js?<?= date('YmdHis'); ?>"></script>
<script src="assets/js/script.js?<?= date('YmdHis'); ?>"></script>

<!-- N2 -->
<script type="text/javascript" src="assets/n2/js/n2.min.js?1570105445" defer async></script>

<!-- Nextend -->
<script type="text/javascript" src="assets/nextend/js/nextend-gsap.min.js?1570105445" defer async></script>
<script type="text/javascript" src="assets/nextend/js/nextend-frontend.min.js?1570105445" defer async></script>
<script type="text/javascript" src="assets/nextend/js/nextend-webfontloader.min.js?1570105445" defer async></script>

<!-- SmartSlider -->
<script type="text/javascript" src="assets/smartslider/js/smartslider-frontend.min.js?1570105445" defer async></script>
<script type="text/javascript" src="assets/smartslider/js/smartslider-block-type-frontend.min.js?1570105445" defer async></script>

<!-- Particles -->
<script type="text/javascript" src="assets/particles/js/particles.min.js?1570105445" defer async></script>


<script type="text/javascript">
	AOS.init({
		duration: 1200,
		once:true
	});
</script>
<script>
    $('.slick-planes').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        appendArrows: '.box-arrows-planes',
        prevArrow:'<a class="arrow-prev ctr_servicios"></a>',
        nextArrow: '<a class="arrow-next ctr_servicios"></a>',
        responsive: [{
            breakpoint: 1200,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
        },{
            breakpoint: 992,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },{
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });
    $('.slick-beneficios').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        appendArrows: '.box-arrows-beneficios',
        prevArrow:'<a class="arrow-prev ctr_beneficios"></a>',
        nextArrow: '<a class="arrow-next ctr_beneficios"></a>',
        responsive: [{
            breakpoint: 1200,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1
            }
        },{
            breakpoint: 992,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
        },{
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },{
            breakpoint: 576,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });
    $('.slick-partners').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        appendArrows: '.box-arrows-partners',
        prevArrow:'<a class="arrow-prev ctr_partners"></a>',
        nextArrow: '<a class="arrow-next ctr_partners"></a>',
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
        },{
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },{
            breakpoint: 576,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });
    $('.slick-socios').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        appendArrows: '.box-arrows-socios',
        prevArrow:'<a class="arrow-prev ctr_socios"></a>',
        nextArrow: '<a class="arrow-next ctr_socios"></a>',
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
        },{
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },{
            breakpoint: 576,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });
</script>
<script>
    $("#form-solicitar-vacante").validate({
        rules: {
            "grado": {required: true},
            "seccion": {required: true}
        },
        messages: {
            "grado": {required: "Este campo es requerido"},
            "seccion": {required: "Este campo es requerido"}
        },
        highlight: function (element, errorClass, validClass) {
            errorClass = "has-error has-feedback";
            validClass = "has-success has-feedback";
            $(element).parents(".form-group").removeClass(validClass).addClass(errorClass);
        }, unhighlight: function (element, errorClass, validClass) {
            errorClass = "has-error has-feedback";
            validClass = "has-success has-feedback";
            $(element).parents(".form-group").removeClass(errorClass).addClass(validClass);
        },
        submitHandler: function (form) {
            var formx = $(form);
            var datos = formx.serializeArray();
            $.ajax({
                type: "post",
                url: "send/solicitar_vacante",
                data: datos,
            }).done(function (msg) {
                $.fancybox.open({
                    src: '#solicitar-vacante-envio',
                    type: 'inline'
                });
                $('.form-control').val("");
            })
        }
    });
    $("#form-matricular").validate({
        rules: {
            "alumnos[nombres]": {required: true},
            "alumnos[apellidos]": {required: true},
            "alumnos[idapoderado]": {required: true},
            "alumnos[dni]": {required: true,number: true},
            "alumnos[sexo]": {required: true},
            "alumnos[fecha_nacimiento]": {required: true},
            "alumnos[telefono]": {required: true,number: true},
            "alumnos[direccion]": {required: true},
            "alumnos[email]": {required: true,email: true}
        },
        messages: {
            "alumnos[nombres]": {required: "Este campo es requerido"},
            "alumnos[apellidos]": {required: "Este campo es requerido"},
            "alumnos[idapoderado]": {required: "Este campo es requerido"},
            "alumnos[dni]": {required: "Este campo es requerido",number: "Ingrese un dni valido"},
            "alumnos[sexo]": {required: "Este campo es requerido"},
            "alumnos[fecha_nacimiento]": {required: "Este campo es requerido"},
            "alumnos[telefono]": {required: "Este campo es requerido",number: "Ingrese un nuero valido"},
            "alumnos[direccion]": {required: "Este campo es requerido"},
            "alumnos[email]": {required: "Este campo es requerido",email: "Ingrese un email valido"}
        },
        highlight: function (element, errorClass, validClass) {
            errorClass = "has-error has-feedback";
            validClass = "has-success has-feedback";
            $(element).parents(".form-group").removeClass(validClass).addClass(errorClass);
        }, unhighlight: function (element, errorClass, validClass) {
            errorClass = "has-error has-feedback";
            validClass = "has-success has-feedback";
            $(element).parents(".form-group").removeClass(errorClass).addClass(validClass);
        },
        submitHandler: function (form) {
            var formx = $(form);
            var datos = formx.serializeArray();
            $.ajax({
                type: "post",
                url: "send/matricular",
                data: datos,
            }).done(function (msg) {
                $.fancybox.open({
                    src: '#matricular-envio',
                    type: 'inline'
                });
                $('.form-control').val("");
            })
        }
    });
</script>
<script>
	$(document).ready(function () {
        $('a[href^="#"]').on('click', function(event) {
            var target = $(this.getAttribute('href'));
            if( target.length ) {
                event.preventDefault();
                $('html, body').stop().animate({
                    scrollTop: target.offset().top
                }, 1000);
            }
        });
        $('a[href^="#"]').click(function() {
            var destino = $(this.hash);
            if (destino.length == 0) {
                destino = $('a[name="' + this.hash.substr(1) + '"]');
            }
            if (destino.length == 0) {
                destino = $('html');
            }
            $('html, body').animate({ scrollTop: destino.offset().top }, 500);
            return false;
        });
	});
</script>
