<?php $menuf = $this->taxonomia->getPaginasFooter(); ?>

<section class="footer" data-aos="fade-up">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-4 info">
                <div class="ctnLogo">
                    <img src="<?= $empresa['logo-blanco'] ?>">
                </div>
                <br>
                <ul class="footer-content">
                    <li class="footer-item">    
                        <p class="footer-link">OFICINA PRINCIPAL</p>
                    </li>
                    <li class="footer-item">    
                        <p class="footer-link"><?= $empresa['direccion'] ?></p>
                    </li>
                    <br>
                    <ul class="footer-content contacto">
                        <li class="footer-item">
                            <a class="footer-link" href="mailto:<?= $empresa['email'] ?>" target="_blank">
                                <span class=""><img src="assets/sources/others/correo.png"> <?= $empresa['email'] ?></span>
                            </a>
                        </li>
                        <li class="footer-item">
                            <a class="footer-link" href="https://api.whatsapp.com/send?phone=51<?= str_replace($stringsE, "", $empresa['telefono']) ?>&text=<?= $empresa['mensaje_whatsapp'] ?>" target="_blank">
                                <span class=""><img src="assets/sources/others/whatsapp.png"> <?= $empresa['telefono'] ?></span>
                            </a>
                        </li>    
                    </ul>
                </ul>
            </div>
            <div class="col-6 col-sm-6 col-md-3">
                <div class="ctnTitle">
                    <h4 class="title">VISITA</h4>
                </div>
                <ul class="footer-content">
                    <?php if (isset($menuf) && !empty($menuf)) { ?>
                    <?php foreach ($menuf as $item) { ?>
                        <li class="footer-item <?= ($item['url'] == $pagina['url']) ? 'active' : ''; ?>">
                            <a class="footer-link" href="<?= $item['url'] ?>"><?= $item['pagina']; ?></a>
                        </li>
                    <?php } ?>
                    <?php } ?>
                </ul>
            </div>
            <div class="col-6 col-sm-6 col-md-3">
                <div class="ctnTitle">
                    <h4 class="title">PLANES</h4>
                </div>
                <ul class="footer-content">
                    <?php if(isset($planes) && !empty($planes)): ?>
                    <?php foreach ($planes as $item){ ?>
                        <li class="footer-item <?= ($item['url'] == $pagina['url']) ? 'active' : ''; ?>">
                            <a class="footer-link" href="plan/<?= $item['url'] ?>"><?= $item['titulo'] ?></a>
                        </li>
                    <?php } ?>
                    <?php endif ?>
                </ul>
            </div>
            <div class="col-12 col-md-2 social">
                <div class="ctnTitle">
                    <h4 class="title">SIGUENOS EN</h4>
                </div>
                <ul class="footer-content">
                    <li class="footer-item">
                        <a class="footer-link" href="<?= $empresa['facebook'] ?>" target="_blank">
                            <span><img src="assets/sources/others/facebook.png"> Empresa</span>
                        </a>
                    </li>
                    <li class="footer-item">
                        <a class="footer-link" href="<?= $empresa['youtube'] ?>" target="_blank">
                            <span><img src="assets/sources/others/youtube.png"> Empresa</span>
                        </a>
                    </li>
                    <li class="footer-item">
                        <a class="footer-link" href="<?= $empresa['instagram'] ?>" target="_blank">
                            <span><img src="assets/sources/others/instagram.png"> Empresa</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12 info">
                <span>ColegioPro 2020 - Todos los derechos reservados</span>
                <span> Diseñado por JRC WEB</span>
             </div>
        </div>
    </div>
 </section>
<!-- &#169; -->
