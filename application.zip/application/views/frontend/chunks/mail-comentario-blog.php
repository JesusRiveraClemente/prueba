<!DOCTYPE html>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <title>ConAmor.pe</title>
    </head>
    <body style="margin:0;padding:0;">
        <table style="border-collapse:collapse;margin:0;padding:0;width:800px;">
            <tr style="padding:0;">
                <td colspan="3" style="background:#fff;;padding:30px 30px 0 30px;">
                    <img src="assets/sources/empresa/conamor-logo.png" alt="logo" width="209" style="width: 100px;float:left;margin:0 0 20px 0;">
                </td>
            </tr>
            <tr style="padding:0;">
                <td colspan="3" style="background:#fff;;padding:30px 30px 0 30px;">
                    <hr style="background:#dcdcdc;border:none;float:left;height:1px;margin:0 0 20px 0;width:100%;">
                    <p style="color:#505050;float:left;font-family:arial;font-size:16px;margin:0 0 20px 0;text-align:left;width:100%;">
                        Nombre: <?= $data['nombre'] ?>
                    </p>
                    <p style="color:#505050;float:left;font-family:arial;font-size:16px;margin:0 0 20px 0;text-align:left;width:100%;">
                        Correo: <?= $data['correo'] ?>
                    </p>
                    <p style="color:#505050;float:left;font-family:arial;font-size:16px;margin:0 0 20px 0;text-align:left;width:100%;">
                        Comentario: <?= $data['comentario'] ?>
                    </p>
                    <hr style="background:#dcdcdc;border:none;float:left;height:1px;margin:0 0 20px 0;width:100%;">
                    <p style="color:#787878;float:left;font-family:arial;font-size:16px;margin:0;text-align:left;width:100%;"><br>conamor.pe .</p>
                </td>
            </tr>           
        </table>
    </body>
</html>