<?php $menuh = $this->taxonomia->getPaginasHeader(); ?>
<?php $stringsE = array(" ","-","/"); ?>

<nav class="navbar navbar-expand-lg navbar-dark">
  <a class="navbar-brand" href="<?= $this->config->base_url(); ?>">
    <img src="<?= $empresa['logo'] ?>">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
    <ul class="navbar-nav">     
        <?php if(isset($menuh) && !empty($menuh)): ?>
        <?php $cont = 1; ?>
        <?php foreach ($menuh as $item): ?>
          <?php if ($cont == 1){ ?>
            <li class="nav-item <?= ($item['url'] == $pagina['url']) ? 'active' : ''; ?> dropdown">
              <a class="nav-link dropdown-toggle" href="<?= $item['url'] ?>">
                <?= $item['pagina']; ?>
              </a>
              <ul class="dropdown-menu">
                <?php if(isset($planes) && !empty($planes)): ?>
                  <?php foreach ($planes as $item) { ?>
                    <a class="dropdown-item" href="plan/<?= $item['url'] ?>"><?= $item['titulo'] ?></a>
                  <?php } ?>
                <?php endif ?>                
              </ul>
            </li>
          <?php }else{ ?>
            <li class="nav-item <?= ($item['url'] == $pagina['url']) ? 'active' : ''; ?>">
              <a class="nav-link" href="<?= $item['url'] ?>" ><?= $item['pagina']; ?></a>
            </li>
          <?php } ?>

          <?php $cont++; ?>
        <?php endforeach ?>
        <?php endif ?>
        <li class="nav-item">
          <!--<a class="nav-link contacto" id="btn-popup-contacto" data-fancybox data-src="#popup-contacto" href="">-->
          <!--  Contáctenos-->
          <!--</a>-->
          <a class="nav-link contacto" id="btn-popup-contacto" href="#">
            Contáctenos
          </a>
        </li>
    </ul>
  </div>
</nav>

<!-- <a href="matricula">
  <div class="ctnMatricula">
    <div class="ctnBody">
      <h1 class="text-center">MATRICULATE AQUI >></h1>
    </div>
  </div>
</a> -->

<div style="display: none;" id="cargando">
  <h2>CARGANDD...</h2>
</div>

<div style="display: none;" id="solicitar-vacante-envio" >
  <center>
    <img src="assets/sources/empresa/esolutiontech-logo.png" alt="logo" >
  </center>
  <br>
  <h2>SOLICITUD DE VACANTE ENVIADO CON EXITO</h2>
</div>

<div style="display: none;" id="matricular-envio" >
  <center>
    <img src="assets/sources/empresa/esolutiontech-logo.png" alt="logo" >
  </center>
  <br>
  <h2>MATRICULADO CON EXITO</h2>
</div>
