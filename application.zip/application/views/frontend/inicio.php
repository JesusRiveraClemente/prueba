<!DOCTYPE html>
<html lang="es" id="inicio">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php
        $pagetitle = $pagina['pagetitle'];
        $meta_description = $pagina['meta_description'];
        $meta_keyword = $pagina['meta_keyword'];

        $og_url = $pagina['og_url'];
        $og_title = $pagina['og_title'];
        $og_description = $pagina['og_description'];
        $og_image = $pagina['og_image'];
    ?>
    <?php include 'chunks/head.php'; ?>
</head>
<body>
    <?php include 'chunks/header-nav.php'; ?>

<div style="display: none;" class="popup" id="popup-contacto">
    <form method="POST" id="form-popup" class="form" action="send/popup">
        <div class="row">
            <div class="col-md-12">
                <img class="portada" src="<?= $contenido['popup_image'] ?>">
            </div>
            <div class="col-md-12 py-3">
                <img src="<?= $contenido['popup_title_image'] ?>">
            </div>
            <div class="col-md-6">
                <div class="form-group">                    
                    <input type="text" class="form-control" name="nombres"  placeholder="Nombres y Apellidos">
                </div>
                <div  class="form-group">
                    <input type="text" class="form-control" name="telefono"  placeholder="Teléfono" maxlength="9" onkeypress="if ( isNaN( String.fromCharCode(event.keyCode) )) return false;">
                </div>
            </div>
            <div class="col-md-6">
                <div  class="form-group">
                    <select class="form-control" name="servicio">
                        <option value="">Seleccionar</option>
                        <?php foreach ($servicios as $item): ?>
                        <option value="<?= clearString($item['titulo']) ?>"><?= $item['titulo']  ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
                <div  class="form-group">
                    <input type="text" class="form-control" name="email"  placeholder="Email">
                </div>
            </div>
            <div class="col-md-12">
                <div class="cont-button text-center">
                    <button type="submit" class="button-ver">ENVIAR</button>
                </div>
            </div>
        </div>
    </form>
</div>

<section class="pd-all" style="background: var(--colorbase1)"></section>

<?php if($contenido['planes_state'] == 1){ ?>
<section class="inicio planes white pd-all" data-aos="fade-up">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12 head" data-aos="fade-up">
                <h1 class="title ftnBack gray text-center"><?= $contenido['planes_title'] ?></h1>
                <p class="description blue"><?= $contenido['planes_description'] ?></p>
            </div>
            <div class="col-xs-12 col-md-12 body" data-aos="fade-up">
                <div class="slick-planes">
                    <?php foreach ($planes as $item): ?>
                        <div style="outline: none;">
                            <div class="ctnPlan">
                            <a class="" href="plan/<?= $item['url'] ?>" style="outline: none;">
                                <div>
                                    <div class="ctnHead">
                                        <img src="<?= $item['icono'] ?>">
                                    </div>
                                    <div class="ctnBody text-center">
                                        <h3><?= $item['titulo'] ?></h3>
                                    </div>
                                    <div class="ctnFooter">
                                        <p><?= $item['descripcion'] ?></p>
                                    </div>
                                </div>
                            </a>
                            </div>
                        </div> 
                    <?php endforeach ?>
                </div>
                <div class="box-arrows-planes"></div>
            </div>
        </div>
    </div>
</section>
<?php } ?>

<?php if($contenido['conocenos_state'] == 1){ ?>
<section class="inicio conocenos white py-7" data-aos="fade-up">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12 body">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-lg-6 py-3 text-center text-lg-left" data-aos="fade-right">
                        <div class="ctnContenido">
                            <div class="ctnHead">
                                <h3><?= $contenido['conocenos_title'] ?></h3>
                            </div>
                            <div class="ctnBody">
                                <h4><?= $contenido['conocenos_description'] ?></h4>
                                <p><?= $contenido['conocenos_content'] ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-lg-6 py-3 d-flex align-items-center justify-content-center justify-content-lg-end" data-aos="fade-left">
                        <div class="ctnBtn">
                            <div class="ctnBody">
                                <a href="nosotros">CONOCENOS MAS >></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php } ?>

<?php if($contenido['beneficios_state'] == 1){ ?>
<section class="inicio beneficios black pd-all" data-aos="fade-up">
    <div class="container-fluid" style="max-width: 1400px">
        <div class="row">
            <div class="col-xs-12 col-md-12 head">
                <h1 class="title ftnBack black text-center"><?= $contenido['beneficios_title'] ?></h1>
                <p class="description"><?= $contenido['beneficios_description'] ?></p>
            </div>
            <div class="col-xs-12 col-md-12 body">
                <div class="slick-beneficios">
                    <?php foreach ($beneficios as $item): ?>
                        <div style="outline: none;">
                            <div class="ctnBeneficio">
                            <a class="" href="" style="outline: none;cursor: default;">
                                <div>
                                    <div class="ctnHead">
                                        <img src="<?= $item['imagen'] ?>">
                                    </div>
                                    <div class="ctnBody text-center">
                                        <h3><?= $item['titulo'] ?></h3>
                                    </div>
                                    <div class="ctnFooter">
                                        <p><?= $item['descripcion'] ?></p>
                                    </div>
                                </div>
                            </a>
                            </div>
                        </div>
                    <?php endforeach ?>
                </div>
                <div class="box-arrows-beneficios"></div>
            </div>
        </div>
    </div>
</section>
<?php } ?>

<?php if($contenido['galeria_state'] == 1){ ?>
<section class="inicio galeria gray pd-all" data-aos="fade-up">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12 head">
                <h1 class="title ftnBack gray text-center"><?= $contenido['galeria_title'] ?></h1>
                <p class="description blue"><?= $contenido['galeria_description'] ?></p>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="slick-galeria">
            <!-- <?php foreach ($contenido['galeria_imagenes'] as $item): ?>
                <div style="outline: none;">
                    <div class="ctnImagen">
                    <a class="" style="outline: none;">
                        <div>
                            <div class="ctnBody text-center">
                                <img src="<?= $item['item_imagen'] ?>">
                            </div>
                        </div>
                    </a>
                    </div>
                </div>
            <?php endforeach ?> -->
        </div>
        <div class="box-arrows-socios"></div>
    </div>
</section>
<?php } ?>

    <?php include 'chunks/footer.php'; ?>
    <?php include 'chunks/script.php'; ?>

    <script>
        $(window).on('load', function() {
            <?php if ($contenido['popup_state'] == 1) { ?>
                $("#btn-popup-contacto").fancybox().trigger('click');
            <?php } ?>
        });
    </script>
</body>
</html>



