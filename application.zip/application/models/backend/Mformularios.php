<?php

class Mformularios extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    public function getTotal($search = NULL,$idcat=0) {
        if ($search != NULL) {
            $this->db->like('formularios.formulario',$search);
            $this->db->or_like('formularios.servicio',$search);
            $this->db->or_like('formularios.nombres',$search);
            $this->db->or_like('formularios.telefono',$search);
            $this->db->or_like('formularios.email',$search);
            $this->db->or_like('formularios.fecha ',$search);             
        }
        return $this->db->count_all_results('formularios');
    }
    
    public function getFormularios($search = NULL, $length = 0, $start = 0,$idcat=0) {
        if ($search != NULL) {
            $this->db->like('formularios.formulario',$search);
            $this->db->or_like('formularios.servicio',$search);
            $this->db->or_like('formularios.nombres',$search);
            $this->db->or_like('formularios.telefono',$search);
            $this->db->or_like('formularios.email',$search);
            $this->db->or_like('formularios.fecha ',$search); 
        }
        $this->db->order_by('formularios.fecha');
        $this->db->limit($length, $start);
        $query=$this->db->get('formularios');
        return $query->result_array();
    }
    public function getFormulario($idform=0){
        $this->db->where('formularios.idformulario',$idform);
        $query=$this->db->get('formularios');
        return $query->row_array();
    }
}
