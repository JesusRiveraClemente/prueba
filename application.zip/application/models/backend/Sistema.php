<?php
class Sistema extends CI_Model {

    public function __construct() {
        parent::__construct(); 
    }
    
    // SELECT * FROM perfil_modulos where idmodulo='1' and idperfil='3'
    public function getPermisos($idp=0,$idm=0){
        $this->db->where(array(
            'idmodulo'=>$idm,
            'idperfil'=>$idp
        ));
        $query=$this->db->get('perfil_modulos');
        return $query->row_array(); 
    }
    
    // select * from modulos where modulos.activo='1' order BY modulos.orden asc
    // select * from modulos inner join perfil_modulos on modulos.idmodulo=perfil_modulos.idmodulo where modulos.activo='1' and perfil_modulos.idperfil='3' and perfil_modulos.ver='1'
    public function getModulos($user=0){
        if($user>0){
            $this->db->join('perfil_modulos','modulos.idmodulo=perfil_modulos.idmodulo');
        }
        $this->db->where('modulos.activo',1);
        if($user>0){
            $this->db->where('perfil_modulos.idperfil',$user);
            $this->db->where('perfil_modulos.ver',1);
        }
        $this->db->order_by('modulos.orden asc');
        $query=$this->db->get('modulos');
        return $query->result_array();
    }
    
    // SELECT sys_users.*,perfiles.perfil,sys_users_profile.* FROM sys_users INNER join sys_users_profile on sys_users.iduser=sys_users_profile.iduser inner join perfiles sys_users.idperfil=perfiles.idperfil where sys_users.username='developer123' and sys_users.active='1'
    public function getUsuario($usuario = NULL) {
        $this->db->select('sys_users.*,perfiles.perfil,sys_users_profile.*');
        $this->db->join('sys_users_profile','sys_users.iduser=sys_users_profile.iduser','LEFT');
        $this->db->join('perfiles','sys_users.idperfil=perfiles.idperfil');
        $this->db->where(array(
            'sys_users.username' => $usuario,
            'sys_users.active' => 1
        ));
        $query = $this->db->get('sys_users');
        return $query->row_array();
    }
    
    // select * from paginas INNER JOIN sitemap on paginas.idsitemap=sitemap.idsitemap WHERE paginas.idpagina='1'
    public function verpagina($id=0){
        $this->db->join('sitemap','paginas.idsitemap=sitemap.idsitemap');
        $this->db->where('paginas.idpagina',$id);
        $query=$this->db->get('paginas');
        return $query->row_array();
    }
    
    // select contenedor.* from contenido inner join contenedor on contenido.idcontenedor=contenedor.idcontenedor where contenido.idpagina="1" group by contenido.idcontenedor order by contenedor.orden asc
    public function getContenedores($id){
        $this->db->select('contenedor.*');
        $this->db->join('contenedor','contenido.idcontenedor=contenedor.idcontenedor');
        $this->db->where('contenido.idpagina',$id);
        $this->db->order_by('contenedor.orden asc');
        $this->db->group_by('contenido.idcontenedor');
        $query=$this->db->get('contenido');
        return $query->result_array();
    }
    
    // select contenedor.* from contenido inner join contenedor on contenido.idcontenedor=contenedor.idcontenedor group by contenido.idcontenedor order by contenedor.orden asc
    public function getContenedoresG(){
        $this->db->select('contenedor.*');
        $this->db->join('contenedor','empresa.idcontenedor=contenedor.idcontenedor');
        $this->db->order_by('contenedor.orden asc');
        $this->db->group_by('empresa.idcontenedor');
        $query=$this->db->get('empresa');
        return $query->result_array();
    }
    
    // [GET COUNT]
    // select * from planes where activo='1'
    public function totalPlanes(){
        $this->db->where('estado',1);
        $this->db->from('planes');
        return $this->db->count_all_results();
    }
    public function totalBeneficios(){
        $this->db->where('estado',1);
        $this->db->from('beneficios');
        return $this->db->count_all_results();
    }
    public function totalEventos(){
        $this->db->where('estado',1);
        $this->db->from('eventos');
        return $this->db->count_all_results();
    } 
    
    public function getPaginas($idm=0){
        $this->db->join('sitemap','paginas.idsitemap=sitemap.idsitemap');
        $this->db->where('paginas.idparent',0);
        $this->db->where('paginas.idmodulo',$idm);
//        $this->db->where('paginas.estado',1);
//        if($user!=0){
//            $this->db->where('user_paginas.id_user',$user);
//        }
        $this->db->order_by('paginas.orden asc');
        $query=$this->db->get('paginas'); 
        return $query->result_array();
    }
    
    
    
    
    
    
    public function getCategorias(){
        $this->db->where('estado',1);
        $query=$this->db->get('categorias');
        return $query->result_array();
    }
    
    public function getContenido($pagina = 0) {
        $this->db->where(array(
            'idpagina' => $pagina,
        ));
        $this->db->order_by('orden', 'ASC');
        $result = $this->db->get('contenido');
        return $this->salida($result->result_array());
    }
    
    public function getCategoria($ids=0){
        $this->db->where('idsitemap',$ids);
        $query=$this->db->get('categorias');
        return $query->row_array();
    }
    
    public function updatecategoria($jm=array()){
        $this->db->where('idcategoria',$jm['categorias']['idcategoria']);
        return $this->db->update('categorias',$jm['categorias']);
    }
    
    public function verificarCate($idc){
        $this->db->where('idsitemap',$idc);
        $query=$this->db->get('categorias');
        return $query->row_array();
    }

    public function salida($data = array()) {
        $salida = array();
        foreach ($data as $key => $value) {
            switch ($value['tipo']) {
                case 'data':
                    $valor = json_decode($value['valor'], TRUE);
                    break;
                default:
                    $valor = $value['valor'];
                    break;
            }
            $salida[$value['nombre']] = $valor;
        }
        return $salida;
    }
    
    public function getPaginasf($user=0){
        $this->db->select('paginas.*');
        if($user!=0){
            $this->db->join('user_paginas','paginas.idpagina=user_paginas.idpagina');
        }
        $this->db->where('paginas.idparent <>',0);
        $this->db->where('paginas.estado',1);
        if($user!=0){
            $this->db->where('user_paginas.id_user',$user);
        }
        $this->db->order_by('paginas.orden asc');
        $query=$this->db->get('paginas');
        return $query->result_array();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public function getModulo($uri=null){
        $this->db->where('url',$uri);
        $query=$this->db->get('modulos');
        return $query->row_array();
    }
    
    public function getHijos($id=0,$user=0){
        if($user!=0){
            $this->db->join('user_paginas','paginas.idpagina=user_paginas.idpagina','LEFT');
        }
        $this->db->where('paginas.idparent',$id);
        $this->db->where('paginas.estado',1);
        if($user!=0){
            $this->db->where('user_paginas.id_user',$user);
        }
        $this->db->order_by('paginas.orden asc');
        $query=$this->db->get('paginas');
        return $query->result_array();
    }
    
    public function editpagina($datos=array()){
        $this->db->where('idpagina',$datos['paginas']['idpagina']);
        return $this->db->update('paginas',$datos['paginas']);
    }
    
    public function getpaginasit($ids=0){
        $this->db->where('idsitemap',$ids);
        $query=$this->db->get('paginas');
        return $query->row_array();
    }
    
    public function editsitemap($datos=array()){
        $this->db->where('idsitemap',$datos['sitemap']['idsitemap']);
        return $this->db->update('sitemap',$datos['sitemap']);
    }
}
