<?php
class Mbeneficios extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    
    public function getTotal($search = NULL) {
        $this->db->select('beneficios.*');
        if ($search != NULL) {
            $this->db->like('beneficios.titulo',$search);
        }
        return $this->db->count_all_results('beneficios');
    }
    
    public function getBeneficios($search = NULL, $length = 0, $start = 0) {
        $this->db->select('beneficios.*');
        if ($search != NULL) {
            $this->db->like('beneficios.titulo',$search);
        }
        $this->db->order_by('beneficios.idbeneficio');
        $this->db->limit($length, $start);
        $query=$this->db->get('beneficios');
        return $query->result_array();
    }
    public function getBeneficio($idbeneficio=0){
        $this->db->where('beneficios.idbeneficio',$idbeneficio);
        $query=$this->db->get('beneficios');
        return $query->row_array();
    }
    
    public function updatebeneficio($datos=array()){
        $this->db->where('beneficios.idbeneficio',$datos['beneficios']['idbeneficio']);
        return $this->db->update('beneficios',$datos['beneficios']);
    }

    public function savebeneficio($datos=array()){
        $this->db->insert('beneficios',$datos['beneficios']);
        return $this->db->insert_id();
    }
    
    public function deletebeneficio($idbeneficio=0){
        $this->db->where('beneficios.idbeneficio',$idbeneficio);
        return $this->db->delete('beneficios');
    }
}