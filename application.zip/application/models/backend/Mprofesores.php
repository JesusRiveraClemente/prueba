<?php
class Mprofesores extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    
    public function getTotal($search = NULL,$idcat=0) {
        $this->db->select('profesores.*');
        if ($search != NULL) {
            $this->db->like('profesores.codigo',$search);
        }
        return $this->db->count_all_results('profesores');
    }
    
    public function getProfesores($search = NULL, $length = 0, $start = 0,$idcat = 0) {
        $this->db->select('profesores.*');
        if ($search != NULL) {
            $this->db->like('profesores.codigo',$search);
        }
        $this->db->order_by('profesores.idprofesor');
        $this->db->limit($length, $start);
        $query=$this->db->get('profesores');
        return $query->result_array();
    }
    public function getProfesor($idprofesor=0){
        $this->db->where('profesores.idprofesor',$idprofesor);
        $query=$this->db->get('profesores');
        return $query->row_array();
    }
    
    public function updateprofesor($datos=array()){
        $this->db->where('idprofesor',$datos['profesores']['idprofesor']);
        return $this->db->update('profesores',$datos['profesores']);
    }

    public function saveprofesor($datos=array()){
        $this->db->insert('profesores',$datos['profesores']);
        return $this->db->insert_id();
    }
    
    public function deleteprofesor($idprofesor=0){
        $this->db->where('idprofesor',$idprofesor);
        return $this->db->delete('profesores');
    }
}
