<?php
class Mproductos extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    
    public function getTotal($search = NULL,$idcat=0) {
        $this->db->select('productos.*');
        $this->db->join('sitemap','productos.idsitemap = sitemap.idsitemap','LEFT');
        if ($search != NULL) {
            $this->db->like('productos.nombre',$search);
        }
        return $this->db->count_all_results('productos');
    }
    
    public function getProductos($search = NULL, $length = 0, $start = 0,$idcat = 0) {
        $this->db->select('productos.*');
        $this->db->join('sitemap','productos.idsitemap = sitemap.idsitemap','LEFT');
        if ($search != NULL) {
            $this->db->like('productos.nombre',$search);
        }
        $this->db->order_by('productos.idproducto');
        $this->db->limit($length, $start);
        $query=$this->db->get('productos');
        return $query->result_array();
    }
    public function getProducto($idproducto=0){
        $this->db->join('sitemap','productos.idsitemap = sitemap.idsitemap');
        $this->db->where('productos.idproducto',$idproducto);
        $query=$this->db->get('productos');
        return $query->row_array();
    }
    
    public function updateproducto($datos=array()){
        $this->db->where('idproducto',$datos['productos']['idproducto']);
        return $this->db->update('productos',$datos['productos']);
    }
    public function updatesitemap($datos=array()){
        $this->db->where('idsitemap',$datos['sitemap']['idsitemap']);
        return $this->db->update('sitemap',$datos['sitemap']);
    }

    public function saveproducto($datos=array()){
        $this->db->insert('productos',$datos['productos']);
        return $this->db->insert_id();
    }
    public function savesitemap($datos=array()){
        $this->db->insert('sitemap',$datos['sitemap']);
        return $this->db->insert_id();
    }
    
    public function deleteproducto($idproducto=0){
        $this->db->where('idproducto',$idproducto);
        return $this->db->delete('productos');
    }
    public function deletesitemap($idsitemap=0){
        $this->db->where('idsitemap',$idsitemap);
        return $this->db->delete('sitemap');
    }
}