<?php

class Mcontenido extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    // select * from empresa
    public function getEmpresa() {
        $this->db->where('activo',1);
        $result = $this->db->get('empresa');
        return $this->salida($result->result_array());
    }
    
    // select * from contenido where idpagina='1' and activo='1' order by orden asc
    public function getVariables($id = NULL) {
        $this->db->where(array(
            'idpagina' => $id,
            'activo' => 1
        ));
        $this->db->order_by('orden', 'ASC');

        $query = $this->db->get('contenido');

        return $query->result_array();
    }
    
    // select * from empresa where activo='1' order by orden asc
    public function getVariablesG() {
        $this->db->where(array(
            'activo' => 1
        ));
        $this->db->order_by('orden', 'ASC');
        $query = $this->db->get('empresa');
        return $query->result_array();
    }
    
    // update contenido set * where nombre="" and idpagina="" 
    public function setVariable($data = array()) {
        $this->db->where(array(
            'nombre' => $data['nombre'],
            'idpagina'=>$data['idpagina']
        ));
        return $this->db->update('contenido', $data);
    }
    // General
    public function setVariableG($data = array()) {
        $this->db->where(array(
            'nombre' => $data['nombre']
        ));
        return $this->db->update('empresa', $data);
    }
    
    
    
    
    
    public function getPaginas($search = NULL, $length = 0, $start = 0){
        $this->db->join('sitemap','paginas.idsitemap=sitemap.idsitemap');
        if ($search != NULL) {
            $this->db->like('paginas.pagina',$search);
            $this->db->or_like('sitemap.url',$search);
        }
        $this->db->limit($length, $start);
        $query=$this->db->get('paginas');
        return $query->result_array();
    }
    
    public function getTotal($search = NULL) {
        $this->db->join('sitemap','paginas.idsitemap=sitemap.idsitemap');
        if ($search != NULL) {
            $this->db->like('paginas.pagina',$search);
            $this->db->or_like('sitemap.url',$search);
        }
        return $this->db->count_all_results('paginas');
    }
    
    public function deletepagina($idp=0){
        $this->db->where('idpagina',$idp);
        return $this->db->delete('paginas');
    }
    
    public function salida($data = array()) {
        $salida = array();
        foreach ($data as $key => $value) {
            switch ($value['tipo']) {
                case 'data':
                    $valor = json_decode($value['valor'], TRUE);
                    break;
                default:
                    $valor = $value['valor'];
                    break;
            }
            $salida[$value['nombre']] = $valor;
        }
        return $salida;
    }
}
