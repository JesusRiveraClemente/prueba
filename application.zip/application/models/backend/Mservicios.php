<?php
class Mservicios extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    
    public function getTotal($search = NULL,$idcat=0) {
        $this->db->select('servicios.*');
        $this->db->join('sitemap','servicios.idsitemap = sitemap.idsitemap','LEFT');
        if ($search != NULL) {
            $this->db->like('servicios.titulo',$search);
        }
        return $this->db->count_all_results('servicios');
    }
    
    public function getServicios($search = NULL, $length = 0, $start = 0,$idcat = 0) {
        $this->db->select('servicios.*');
        $this->db->join('sitemap','servicios.idsitemap = sitemap.idsitemap','LEFT');
        if ($search != NULL) {
            $this->db->like('servicios.titulo',$search);
        }
        $this->db->order_by('servicios.idservicio');
        $this->db->limit($length, $start);
        $query=$this->db->get('servicios');
        return $query->result_array();
    }
    public function getServicio($idservicio=0){
        $this->db->join('sitemap','servicios.idsitemap = sitemap.idsitemap');
        $this->db->where('servicios.idservicio',$idservicio);
        $query=$this->db->get('servicios');
        return $query->row_array();
    }
    
    public function updatesitemap($datos=array()){
        $this->db->where('idsitemap',$datos['sitemap']['idsitemap']);
        return $this->db->update('sitemap',$datos['sitemap']);
    }
    public function updateservicio($datos=array()){
        $this->db->where('idservicio',$datos['servicios']['idservicio']);
        return $this->db->update('servicios',$datos['servicios']);
    }

    public function saveservicio($datos=array()){
        $this->db->insert('servicios',$datos['servicios']);
        return $this->db->insert_id();
    }
    public function savesitemap($datos=array()){
        $this->db->insert('sitemap',$datos['sitemap']);
        return $this->db->insert_id();
    }
    
    public function deleteservicio($idservicio=0){
        $this->db->where('idservicio',$idservicio);
        return $this->db->delete('servicios');
    }
    public function deletesitemap($idsitemap=0){
        $this->db->where('idsitemap',$idsitemap);
        return $this->db->delete('sitemap');
    }
}