<?php
class Mblogs extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    
    public function getTotal($search = NULL,$idcat=0) {
        $this->db->select('blogs.*');
        $this->db->join('sitemap','blogs.idsitemap = sitemap.idsitemap','LEFT');
        if ($search != NULL) {
            $this->db->like('blogs.titulo',$search);
        }
        return $this->db->count_all_results('blogs');
    }
    
    public function getBlogs($search = NULL, $length = 0, $start = 0,$idcat = 0) {
        $this->db->select('blogs.*');
        $this->db->join('sitemap','blogs.idsitemap = sitemap.idsitemap','LEFT');
        if ($search != NULL) {
            $this->db->like('blogs.titulo',$search);
        }
        $this->db->order_by('blogs.idblog','ASC');
        $this->db->limit($length, $start);
        $query=$this->db->get('blogs');
        return $query->result_array();
    }
    public function getBlog($idblog=0){
        $this->db->join('sitemap','blogs.idsitemap = sitemap.idsitemap');
        $this->db->where('blogs.idblog',$idblog);
        $query=$this->db->get('blogs');
        return $query->row_array();
    }
    
    public function updatesitemap($datos=array()){
        $this->db->where('idsitemap',$datos['sitemap']['idsitemap']);
        return $this->db->update('sitemap',$datos['sitemap']);
    }
    public function updateblog($datos=array()){
        $this->db->where('idblog',$datos['blogs']['idblog']);
        return $this->db->update('blogs',$datos['blogs']);
    }

    public function savesitemap($datos=array()){
        $this->db->insert('sitemap',$datos['sitemap']);
        return $this->db->insert_id();
    }
    public function saveblog($datos=array()){
        $this->db->insert('blogs',$datos['blogs']);
        return $this->db->insert_id();
    }
    
    public function deletesitemap($idsitemap=0){
        $this->db->where('idsitemap',$idsitemap);
        return $this->db->delete('sitemap');
    }
    public function deleteblog($idblog=0){
        $this->db->where('idblog',$idblog);
        return $this->db->delete('blogs');
    }
    
    // Comentarios
    public function getComentarios($idblog){
        $this->db->where('comentarios.idblog',$idblog);
        $query=$this->db->get('comentarios');
        return $query->result_array();
    }
    public function updatecomentarios($datos=array()){
        $this->db->where('idcomentario',$datos['idcomentario']);
        return $this->db->update('comentarios',$datos);
    }
}