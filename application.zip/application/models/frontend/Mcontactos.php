<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mcontactos extends CI_Model {

	public function __construct() {
        parent::__construct();
    }

	public function index(){
	}

	public function saveMatricula($datos=array()){
		$this->db->insert('matriculas',$datos['matriculas']);
		return $this->db->insert_id();
	}
	public function updateMatricula($datos=array()){
        $this->db->where('codigo',$datos['matriculas']['codigo']);
        return $this->db->update('matriculas',$datos['matriculas']);
    }

    public function saveAlumno($datos=array()){
		$this->db->insert('alumnos',$datos['alumnos']);
		return $this->db->insert_id();
	}
}

/* End of file Mcontactos.php */
/* Location: ./application/models/frontend/Mcontactos.php */

