<?php
class Contenido extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function getEmpresa() {
        $this->db->where('activo',1);
        $result = $this->db->get('empresa');
        return $this->salida($result->result_array());
    }
    public function getContenido($pagina = 0) {
        $this->db->where(array('idpagina' => $pagina));
        $result = $this->db->get('contenido');
        return $this->salida($result->result_array()); 
    }
    
    public function getPlanes(){
        $this->db->join('sitemap','planes.idsitemap=sitemap.idsitemap');
        $this->db->where(array(
            'planes.estado'=>1
        ));
        $this->db->order_by('planes.idplan ASC');
        $query=$this->db->get('planes');
        return $query->result_array();
    }
    public function getBeneficios(){
        $this->db->where(array(
            'beneficios.estado'=>1
        ));
        $this->db->order_by('beneficios.idbeneficio DESC');
        $query=$this->db->get('beneficios');
        return $query->result_array();
    }
    public function getEventos(){
        $this->db->where(array(
            'eventos.estado'=>1
        ));
        $this->db->order_by('eventos.idevento DESC');
        $query=$this->db->get('eventos');
        return $query->result_array();
    }

    public function getGrados(){
        $this->db->where(array(
            'grados.estado'=>1
        ));
        $this->db->order_by('grados.idgrado ASC');
        $query=$this->db->get('grados');
        return $query->result_array();
    }
    public function getSecciones(){
        $this->db->where(array(
            'secciones.estado'=>1
        ));
        $this->db->order_by('secciones.idseccion ASC');
        $query=$this->db->get('secciones');
        return $query->result_array();
    }

    public function salida($data = array()) {
        $salida = array();
        foreach ($data as $key => $value) {
            switch ($value['tipo']) {
                case 'data':
                    $valor = json_decode($value['valor'], TRUE);
                    break;
                default:
                    $valor = $value['valor'];
                    break;
            }
            $salida[$value['nombre']] = $valor;
        }
        return $salida;
    }
}
