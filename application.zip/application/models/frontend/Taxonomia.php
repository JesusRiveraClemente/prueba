<?php
class Taxonomia extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    public function getPlanurl($urlPlan=NULL){
        $this->db->select('sitemap.*,planes.*');
        $this->db->join('planes','sitemap.idsitemap=planes.idsitemap');
        $this->db->where('sitemap.url',$urlPlan);
        $query=$this->db->get('sitemap');
        return $query->row_array();
    }

    public function getPaginaurl($url=NULL){
        $this->db->select('paginas.*,templates.template,sitemap.*');
        $this->db->join('templates','paginas.idpagina=templates.idpagina');
        $this->db->join('sitemap','paginas.idsitemap=sitemap.idsitemap');
        $this->db->where('sitemap.url',$url);
        $query=$this->db->get('paginas');
        return $query->row_array(); 
    }

    public function getSalon($idgrado=NULL,$idseccion=NULL){
        $this->db->where(array(
            'salones.idgrado'=>$idgrado,
            'salones.idseccion'=>$idseccion
        ));
        $query=$this->db->get('salones');
        return $query->row_array();
    }

    public function getMatricula($codigo){
        $this->db->where(array(
            'matriculas.codigo'=>$codigo,
            'matriculas.estado'=>1
        ));
        $query=$this->db->get('matriculas');
        return $query->row_array();
    }

    // select * from paginas inner join sitemap on paginas.idsitemap=sitemap.idsitemap where paginas.header='1' and paginas.estado='1' order by  paginas.orden ASC
    public function getPaginasHeader(){
        $this->db->join('sitemap','paginas.idsitemap=sitemap.idsitemap');
        $this->db->where(array(
            'paginas.header'=>1,
            'paginas.estado'=>1
        ));
        $this->db->order_by('paginas.orden asc');
        $query=$this->db->get('paginas');
        return $query->result_array();
    }
    // select * from paginas inner join sitemap on paginas.idsitemap=sitemap.idsitemap where paginas.footer='1' and paginas.estado='1' order by  paginas.orden ASC
    public function getPaginasFooter(){
        $this->db->join('sitemap','paginas.idsitemap=sitemap.idsitemap');
        $this->db->where(array(
            'paginas.footer'=>1,
            'paginas.estado'=>1
        ));
        $this->db->order_by('paginas.orden asc');
        $query=$this->db->get('paginas');
        return $query->result_array();
    }
}
